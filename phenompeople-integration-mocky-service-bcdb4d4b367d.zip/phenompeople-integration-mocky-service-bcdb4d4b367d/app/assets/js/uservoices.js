(function(){var uv=document.createElement('script');uv.type='text/javascript';uv.async=true;uv.src='//widget.uservoice.com/nIFm1w8BswV6OuuCXMdbAw.js';var s=document.getElementsByTagName('script')[0];s.parentNode.insertBefore(uv,s)})()
UserVoice = window.UserVoice || [];
UserVoice.push(['showTab', 'classic_widget', {
    mode: 'feedback',
    primary_color: '#64add1',
    link_color: '#007dbf',
    forum_id: 205182,
    tab_label: I18n("feedback"),
    tab_color: '#64add1',
    tab_position: 'bottom-right',
    tab_inverted: false
}]);
