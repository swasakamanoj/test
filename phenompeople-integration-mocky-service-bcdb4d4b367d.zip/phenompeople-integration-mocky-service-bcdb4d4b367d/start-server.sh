#!/usr/bin/env bash
if [ -f ${PROJECT_HOME}/RUNNING_PID ]; then
  source ${APP_HOME}/stop-server.sh
fi
ln -sf ${APP_HOME}/buildproperties/configuration.conf ${PROJECT_HOME}/conf/configuration.conf
${PROJECT_HOME}/bin/${PROJECT_NAME} -Dconfig.resource=configuration.conf

