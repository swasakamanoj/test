#!/usr/bin/env bash
kill -TERM  $(cat ${PROJECT_HOME}/RUNNING_PID)
rm -f ${PROJECT_HOME}/RUNNING_PID
