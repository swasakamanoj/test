#!/usr/bin/env bash
mkdir -p $PWD/tmp
sbt -Djava.io.tmpdir=$PWD/tmp stage
rm -rf $PWD/tmp