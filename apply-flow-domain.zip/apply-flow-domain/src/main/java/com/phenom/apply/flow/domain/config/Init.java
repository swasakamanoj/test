package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Init {

    private List<PreReqObject> preReqObjects;
    private List<FieldMapper> addToMetadataObject;

    /**
     * Default Constructor
     */
    public Init() {

    }

    public List<PreReqObject> getPreReqObjects() {
        return preReqObjects;
    }

    public void setPreReqObjects(List<PreReqObject> preReqObjects) {
        this.preReqObjects = preReqObjects;
    }

    public List<FieldMapper> getAddToMetadataObject() {
        return addToMetadataObject;
    }

    public void setAddToMetadataObject(List<FieldMapper> addToMetadataObject) {
        this.addToMetadataObject = addToMetadataObject;
    }
}
