package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.phenom.apply.flow.domain.enums.RuleConditionEnum;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IfRuleConfig implements PhenomRule{

    private RuleConditionEnum condition;
    private List<IfRule> rules;
    private RuleResultProcess pass;
    private FailRuleResultProcess fail;

    public RuleConditionEnum getCondition() {
        return condition;
    }

    public void setCondition(RuleConditionEnum condition) {
        this.condition = condition;
    }

    @JsonDeserialize(using = IfRuleDeserialize.class)
    public List<IfRule> getRules() {
        return rules;
    }

    public void setRules(List<IfRule> rules) {
        this.rules = rules;
    }

    public RuleResultProcess getPass() {
        return pass;
    }

    public void setPass(RuleResultProcess pass) {
        this.pass = pass;
    }

    public FailRuleResultProcess getFail() {
        return fail;
    }

    public void setFail(FailRuleResultProcess fail) {
        this.fail = fail;
    }
}
