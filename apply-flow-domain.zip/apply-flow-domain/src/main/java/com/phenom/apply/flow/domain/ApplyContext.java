package com.phenom.apply.flow.domain;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.phenom.apply.flow.domain.constants.FlowConstants;
import com.phenom.apply.flow.domain.enums.SourceObjectEnum;

import java.util.Map;

public class ApplyContext extends ObjectNode {

    private boolean offline;

    ApplyContext(JsonNodeFactory nc) {
        super(nc);
    }

    ApplyContext(JsonNodeFactory nc, Map<String, JsonNode> kids) {
        super(nc, kids);
    }

    public boolean isOffline() {
        return offline;
    }

    public void setOffline(boolean offline) {
        this.offline = offline;
    }

    public String getApplySubmitType() {
        if (this.get(FlowConstants.APPLY_SUBMIT_TYPE) != null && !this.get(FlowConstants.APPLY_SUBMIT_TYPE).asText().equals("")) {
            return this.get(FlowConstants.APPLY_SUBMIT_TYPE).asText();
        }
        return FlowConstants.APPLY_SUBMIT_ONLINE_TYPE;
    }

    public String getRefNum() {
        return this.get(FlowConstants.REFNUM).asText();
    }

    public String getParentRefNum() {
        if (this.get(FlowConstants.PARENT_REFNUM) == null) {
            return getRefNum();
        } else {
            return this.get(FlowConstants.PARENT_REFNUM).asText();
        }
    }

    /**
     * Method to get metadata from the apply context
     *
     * @return {@link JsonNode}
     */
    public Metadata getMetadata() {
        return ( Metadata ) this.get(SourceObjectEnum.META_DATA.sourceObject());
    }

    /**
     * Method to get job from the apply context
     *
     * @return {@link JsonNode}
     */
    public Job getJob() {
        return ( Job ) this.get(SourceObjectEnum.JOB.sourceObject());
    }

    /**
     * Method to get apply status from the apply context
     *
     * @return {@link JsonNode}
     */
    public AtsApplyStatus getApplyStatus() {
        return ( AtsApplyStatus ) this.get(SourceObjectEnum.ATS_APPLY_STATUS.sourceObject());
    }

    /**
     * Method to get apply data from the apply context
     *
     * @return {@link JsonNode}
     */
    public AtsApplyData getApplyData() {
        return ( AtsApplyData ) this.get(SourceObjectEnum.ATS_APPLY_DATA.sourceObject());
    }

    /**
     * @return {@link JsonNode}
     */
    public Request getRequest() {
        return ( Request ) this.get(SourceObjectEnum.REQUEST.sourceObject());
    }

    /**
     * Method to get object from the apply context
     *
     * @param applyContext     {@code {@link JsonNode }}
     * @param applyObjectsEnum {@code {@link JsonNode }}
     * @return {@link JsonNode}
     */
    public JsonNode getObject(ApplyContext applyContext, SourceObjectEnum applyObjectsEnum) {
        return applyContext.get(applyObjectsEnum.sourceObject());
    }

    public String getStatus() {
        if (this.get(FlowConstants.STATUS_KEY) != null) {
            return this.get(FlowConstants.STATUS_KEY).asText();
        }
        return "";
    }

    public void setStatus(String status) {
        this.put(FlowConstants.STATUS_KEY, status);
    }

    public String getStatusCode() {
        if (this.get(FlowConstants.STATUS_CODE_KEY) != null) {
            return this.get(FlowConstants.STATUS_CODE_KEY).asText();
        }
        return "";
    }

    public void setStatusCode(String status) {
        this.put(FlowConstants.STATUS_CODE_KEY, status);
    }

    public String getStatusMessage() {
        if (this.get(FlowConstants.STATUS_MESSAGE_KEY) != null) {
            return this.get(FlowConstants.STATUS_MESSAGE_KEY).asText();
        }
        return "";
    }

    public void setStatusMessage(String status) {
        this.put(FlowConstants.STATUS_MESSAGE_KEY, status);
    }

    public JsonNode getCommon() {
        if (this.getRequest() != null) {
            return this.getRequest().get(FlowConstants.COMMON);
        }
        return null;
    }

    public String getApplyType() {
        if (this.get(FlowConstants.APPLY_TYPE) != null) {
            return this.get(FlowConstants.APPLY_TYPE).asText();
        }
        return "";
    }
    
    public void setGetOnlyForm(boolean getOnlyForm) {
        this.put(FlowConstants.GET_ONLY_FORM, getOnlyForm);
    }

    public boolean isGetOnlyForm() {
    	if(this.get(FlowConstants.GET_ONLY_FORM) != null) {
           return this.get(FlowConstants.GET_ONLY_FORM).asBoolean();
    	}
    	return false;
    }
    
    public void setGotoStepNum(String gotoStepNum) {
        this.put(FlowConstants.GOTO_STEPNUM, gotoStepNum);
    }

    public String getGotoStepNum() {
    	if(this.get(FlowConstants.GOTO_STEPNUM) != null) {
           return this.get(FlowConstants.GOTO_STEPNUM).asText();
    	}
    	return null;
    }

}
