package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.phenom.apply.flow.domain.enums.SourceObjectEnum;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldMapper extends FieldValue {

    private SourceObjectEnum sourceObject; //It should be a enum
    private String sourceFieldName;
    private List<String> childOf;


    public FieldMapper() {
    }

    public FieldMapper(String metadataKey, JsonNode value) {
        super(metadataKey, value);
    }

    public FieldMapper(SourceObjectEnum sourceObject, String sourceFieldName) {
        this.sourceObject = sourceObject;
        this.sourceFieldName = sourceFieldName;
    }

    public FieldMapper(String metadataKey, SourceObjectEnum sourceObject, String sourceFieldName) {
        super(metadataKey);
        this.sourceObject = sourceObject;
        this.sourceFieldName = sourceFieldName;
    }

    public FieldMapper(String metadataKey, SourceObjectEnum sourceObject, String sourceFieldName,
                       List<String> childOf) {
        super(metadataKey);
        this.sourceObject = sourceObject;
        this.sourceFieldName = sourceFieldName;
        this.childOf = childOf;
    }

    public FieldMapper(SourceObjectEnum sourceObject, String sourceFieldName, List<String> childOf) {
        this.sourceObject = sourceObject;
        this.sourceFieldName = sourceFieldName;
        this.childOf = childOf;
    }

    /**
     * @return
     */
    public SourceObjectEnum getSourceObject() {
        return sourceObject;
    }

    public void setSourceObject(SourceObjectEnum sourceObject) {
        this.sourceObject = sourceObject;
    }

    public String getSourceFieldName() {
        return sourceFieldName;
    }

    public void setSourceFieldName(String sourceFieldName) {
        this.sourceFieldName = sourceFieldName;
    }

    public List<String> getChildOf() {
        return childOf;
    }

    public void setChildOf(List<String> childOf) {
        this.childOf = childOf;
    }


}
