package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define applyMaintenance flags
 *
 * @author Venu
 */

public enum InternalApplyServiceEnum {

    NONE("NONE"),
    ALREADY_APPLIED("ALREADY_APPLIED"),
    JSQS("JSQS"),
    GET_PSQ_FORM("GET_PSQ_FORM"),
    VALIDATE_PSQ_ANSWERS("VALIDATE_PSQ_ANSWERS");

    private String internalApplyService;

  /**
   * Constructor method
   *
   * @param internalApplyService
   */
  InternalApplyServiceEnum(String internalApplyService) {
      this.internalApplyService = internalApplyService;
    }

  /**
   * Method to get internalApplyService id string from ENUM
   * @return String
   */
  public String internalApplyService() {
      return internalApplyService;
    }

  }
