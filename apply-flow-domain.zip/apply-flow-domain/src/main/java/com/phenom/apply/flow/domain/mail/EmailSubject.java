package com.phenom.apply.flow.domain.mail;

/**
 * @author Manoj Swasaka on 9/3/19
 * @project apply-flow-domain
 */
public class EmailSubject {

    private String eMailSubject;

    private String[] mappingFields;

    public String[] getMappingFields() {
        return mappingFields;
    }

    public void setMappingFields(String[] mappingFields) {
        this.mappingFields = mappingFields;
    }

    public String geteMailSubject() {
        return eMailSubject;
    }

    public void seteMailSubject(String eMailSubject) {
        this.eMailSubject = eMailSubject;
    }
}
