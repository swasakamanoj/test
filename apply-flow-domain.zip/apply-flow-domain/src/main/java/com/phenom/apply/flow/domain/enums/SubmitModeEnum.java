package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum SubmitModeEnum {
    IN_EVERY_STEP("IN_EVERY_STEP"),
    IN_FINAL_STEP("IN_FINAL_STEP");

    private String submitMode;

    /**
     * Constructor method
     *
     * @param submitMode
     */
    SubmitModeEnum(String submitMode) {
        this.submitMode = submitMode;
    }

    /**
     * Method to get submitMode string from ENUM
     * @return String
     */
    public String submitMode() {
        return submitMode;
    }

}
