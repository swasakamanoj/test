package com.phenom.apply.flow.domain.enums;

import org.slf4j.Marker;
import org.slf4j.MarkerFactory;

/**
 *
 * Enum to define applyMaintenance flags
 *
 * @author Venu
 */

public enum StatusCodeEnum {

    FS_SUCCESS_CODE("SUCCESS", "%s submitted successfully"),
    FS_SUCCESS_DISQUALIFIED_CODE("FS_SUCCESS_DISQUALIFIED_CODE", "Candidate is disqualified for the job."),
    FS_ALREADY_APPLIED_CODE("FS_ALREADY_APPLIED_CODE", "Already Applied."),

    //******** JOB ***********//
    FS_JOB_EXPIRED_ERROR("FS_JOB_EXPIRED_ERROR", "Job expired or not found.", MarkerFactory.getMarker("PP_APPLY_SERVICE_SEARCH_ERROR")),
    FS_JOB_EXPIRED_AT_ATS_ERROR("FS_JOB_EXPIRED_AT_ATS_ERROR", "Job expired at ATS end"),
    FS_JOB_FETCHING_ERROR("FS_JOB_FETCHING_ERROR", "Error while fetching job data"),

    //FLOW SERVICE CODES
    FS_BEAN_CREATION_ERROR("FS_BEAN_CREATION_ERROR", "Exception while creating apply beans for class %s"),
    FS_BEAN_ADD_ERROR("FS_BEAN_ADD_ERROR", "%s will not be be added to apply context"),
    FS_INTERNAL_ERROR("FS_INTERNAL_ERROR", "Internal error while processing apply"),

    //********** INIT *****************//
    FS_INIT_ERROR("FS_INIT_ERROR", "Exception while processing init method."),
    FS_INIT_PRE_REQ_OBJECTS_ERROR("FS_INIT_PRE_REQ_OBJECTS_ERROR", "Exception while creating pre req objects."),
    FS_INIT_JOB_PRE_REQ_OBJECTS_ERROR("FS_INIT_JOB_PRE_REQ_OBJECTS_ERROR", "Exception while creating job pre req object."),
    FS_INIT_JOB_FIELD_NOT_FOUNT_ERROR("FS_INIT_JOB_FIELD_NOT_FOUNT_ERROR", "%s field data not found in the job data, please contact jobpull team."),
    FS_INIT_LOADING_INIT_METADATA_ERROR("FS_INIT_LOADING_INIT_METADATA_ERROR", "Exception while loading init metadata."),
    FS_INIT_STEP_ERROR("FS_INIT_STEP_ERROR", "Exception while initialising step data."),

    //****************FLOW**********//
    FS_FLOW_CONFIG_LOADING_ERROR("FS_FLOW_CONFIG_LOADING", "Exception while loading flow config."),
    FS_FLOW_CONFIG_NOT_FOUND_ERROR("FS_FLOW_CONFIG_NOT_FOUND_ERROR", "Flow config not found."),
    FS_FLOW_CODE_LOADING_ERROR("FS_FLOW_CODE_LOADING_ERROR", "Exception while loading flow code."),
    FS_FLOW_CODE_IDENTIFIER_NOT_FOUND_ERROR("FS_FLOW_CODE_IDENTIFIER_NOT_FOUND_ERROR", "Flow code identifier configuration is not found."),
    FS_FLOW_CODE_NOT_FOUND_ERROR("FS_FLOW_CODE_NOT_FOUND_ERROR", "Flow code is not found."),
    FS_APPLY_FLOWS_NOT_FOUND_ERROR("FS_APPLY_FLOWS_NOT_FOUND_ERROR", "Flows are not configured in the flow config."),
    FS_FLOW_STEP_SEQ_NOT_FOUND_ERROR("FS_FLOW_STEP_SEQ_NOT_FOUND_ERROR", "Flow step sequence not found."),
    FS_FLOW_STEP_SEQ_LOAD_ERROR("FS_FLOW_STEP_SEQ_LOAD_ERROR", "Flow step sequence not found."),

    //****** NODE **********//
    FS_NODE_CONFIG_ID_NOT_FOUND_ERROR("FS_NODE_CONFIG_ID_NOT_FOUND_ERROR", "Node config id not found using source node config id: %s"),
    FS_NODE_CONFIG_ID_PROCESSING_ERROR("FS_NODE_CONFIG_ID_PROCESSING_ERROR", "Exception while getting node id from source node config id: %s"),
    FS_NODE_CONFIG_PROCESSING_ERROR("FS_NODE_CONFIG_PROCESSING_ERROR", "Exception while processing node id: %s"),

    //**** RULE ***********//
    FS_RULE_PROCESSING_ERROR("FS_RULE_PROCESSING_ERROR", "Exception while processing rule in node id: %s"),

    //**** INTERNAL SERVICE ********//
    FS_INTERNAL_SERVICE_JSQ_LOADING_ERROR("FS_INTERNAL_SERVICE_JSQ_LOADING_ERROR", "Exception while loading JSQs using internal service through node config id: %s"),
    FS_INTERNAL_SERVICE_ALREADY_APPLIED_ERROR("FS_INTERNAL_SERVICE_ALREADY_APPLIED_ERROR", "Exception while checking already applied using internal service through node config id: %s"),
    FS_INTERNAL_SERVICE_GET_PSQ_FORM_ERROR("FS_INTERNAL_SERVICE_GET_PSQ_FORM_ERROR", "Exception while getting psq form using internal service through node config id: %s"),
    FS_INTERNAL_SERVICE_PSQ_VALIDATE_ERROR("FS_INTERNAL_SERVICE_PSQ_VALIDATE_ERROR", "Exception while validating psq answers using internal service through node config id: %s"),

    //**************GATEWAY SERVICE CODES ********//
    FS_GATEWAY_SYNC_ERROR("FS_GATEWAY_SYNC_ERROR", "Exception while calling gateway synchronously through node config id: %s"),
    FS_GATEWAY_RESPOSE_PROCESSING_ERROR("FS_GATEWAY_RESPONSE_PROCESSING_ERROR", "Exception while processing gateway response for node id: %s"),

    //****** EVENTS SERVICE CALLS **********//
    FS_EVENTS_PREPARING_ERROR("FS_EVENTS_PREPARING_ERROR", "Exception while preparing events"),

    //**************STEP********//
    FS_STEP_NOT_FOUND_ERROR("FS_STEP_NOT_FOUND_ERROR", "Step not found with stepId:%s"),
    FS_STEPS_NOT_FOUND_ERROR("FS_STEPS_NOT_FOUND_ERROR", "Steps are not configured in the flow config."),
    FS_STEP_PROCESSING_ERROR("FS_STEP_PROCESSING_ERROR", "Exception while processing step: %s"),
    FS_STEP_SUBMIT_ERROR("FS_STEP_SUBMIT_ERROR", "Exception while submitting step: %s"),
    FS_STEP_SUBMIT_USERNAME_MANDATORY("FS_STEP_SUBMIT_USERNAME_MANDATORY", "Username is mandatory for submit to the gateway"),
    FS_STEP_FORM_INIT_OPERATION_ERROR("FS_STEP_FORM_INIT_OPERATION_ERROR", "Exception while processing form init operation in step: %s"),
    FS_STEP_PRE_OPERATION_ERROR("FS_STEP_PRE_OPERATION_ERROR", "Exception while processing pre operation in step: %s"),
    FS_STEP_POST_OPERATION_ERROR("FS_STEP_POST_OPERATION_ERROR", "Exception while processing post operation in step: %s"),
    FS_STEP_ATS_SUBMIT_ERROR("FS_STEP_ATS_SUBMIT_ERROR", "Exception while submiting to ATS in step: %s"),
    FS_STEP_ATS_APPLY_STATUS_UPDATE_STATUS_ERROR("FS_STEP_ATS_APPLY_STATUS_UPDATE_STATUS_ERROR", "Exception while updating status in the ats apply status."),

    //*********STEP FORM ********//
    FS_STEP_FORM_LOAD_ERROR("FS_STEP_FORM_LOAD_ERROR", "Exception while loading form for next step in step: %s"),
    FS_STEP_FORM_PREPARE_KEY_ERROR("FS_STEP_FORM_PREPARE_KEY_ERROR", "Exception while preparing key to load form from redis in step: %s"),

    //*******Response Processing*******//
    FS_RESPONSE_FINAL_PROCESSING_ERROR("FS_RESPONSE_FINAL_PROCESSING_ERROR", "Exception while processing final response in step: %s"),
    FS_RESPONSE_APPLY_GATEWAY_PROCESSING_ERROR("FS_RESPONSE_APPLY_GATEWAY_PROCESSING_ERROR", "Exception while processing apply gateway response: %s"),
    FS_RESPONSE_APPLY_EVENTS_PROCESSING_ERROR("FS_RESPONSE_APPLY_EVENTS_PROCESSING_ERROR", "Exception while processing apply events response: %s"),

    //********DB HELPER ***********//
    FS_DB_HELPER_UPSERT_ATS_APPLY_STATUS_ERROR("FS_DB_HELPER_UPSERT_ATS_APPLY_STATUS_ERROR", "Exception while upserting ats apply status."),
    FS_DB_HELPER_UPSERT_ATS_APPLY_DATA_ERROR("FS_DB_HELPER_UPSERT_ATS_APPLY_DATA_ERROR", "Exception while upserting ats apply data."),
    FS_DB_HELPER_PREPARE_ATS_APPLY_DATA_QUERY_ERROR("FS_DB_HELPER_PREPARE_ATS_APPLY_DATA_QUERY_ERROR", "Exception while preparing query to upsert ats apply data."),
    FS_DB_HELPER_PREPARE_ATS_APPLY_STATUS_QUERY_ERROR("FS_DB_HELPER_PREPARE_ATS_APPLY_STATUS_QUERY_ERROR", "Exception while preparing query to upsert ats apply status."),
    FS_DB_HELPER_ID_REPLACE_ERROR("FS_DB_HELPER_ID_REPLACE_ERROR", "Exception while processing final response in step: %s"),
    FS_DB_HELPER_JSQ_ERROR("FS_DB_HELPER_JSQ_ERROR", "Exception while processing JSQs."),
    FS_DB_HELPER_ALREADY_APPLIED_ERROR("FS_DB_HELPER_ALREADY_APPLIED_ERROR", "Exception while processing already applied."),

    //*********Mongo********//
    FS_MONGO_CREATING_MONGO_CLIENT_ERROR("FS_MONGO_CREATING_MONGO_CLIENT_ERROR", "Exception while creating mongo client."),
    FS_MONGO_INSERT_DOCUMENT_ERROR("FS_MONGO_INSERT_DOCUMENT_ERROR", "Exception while inserting document."),
    FS_MONGO_UPDATE_DOCUMENT_ERROR("FS_MONGO_UPDATE_DOCUMENT_ERROR", "Exception while updating document."),
    FS_MONGO_FIND_DOCUMENT_ERROR("FS_MONGO_FIND_DOCUMENT_ERROR", "Exception while finding document."),
    FS_MONGO_FIND_DOCUMENTS_ERROR("FS_MONGO_FIND_DOCUMENTS_ERROR", "Exception while finding documents."),
    FS_MONGO_UPSERT_DOCUMENT_ERROR("FS_MONGO_UPSERT_DOCUMENT_ERROR", "Exception while upsert document."),
    FS_MONGO_TIME_OUT_ERROR("FS_MONGO_TIME_OUT_ERROR", "Mongo timeout error."),

    //*********REDIS *************//
    FS_REDIS_CONNECTION_ERROR("FS_REDIS_CONNECTION_ERROR", "Exception while connecting redis."),
    FS_REDIS_GET_VALUE_ERROR("FS_REDIS_GET_VALUE_ERROR", "Exception while getting value from redis using key %s"),

    FS_URL_REQUEST_PROCESSING_ERROR("FS_URL_REQUEST_PROCESSING_ERROR", "Exception while requesting url %s", MarkerFactory.getMarker("PP_APPLY_INTERNAL_SERVICE_API_FAILED")),
    FS_URL_REQUEST_TIMEOUT_ERROR("FS_URL_REQUEST_TIMEOUT_ERROR", "Timeout error while requesting url %s", MarkerFactory.getMarker("PP_APPLY_INTERNAL_SERVICE_TIMEOUT")),
    FS_URL_REQUEST_CONNECTION_ERROR("FS_URL_REQUEST_CONNECTION_ERROR", "Exception while connecting url %s", MarkerFactory.getMarker("PP_APPLY_INTERNAL_SERVICE_UNAVAILABLE")),
    FS_URL_SSL_HANDSHAKE_ERROR("FS_URL_SSL_HANDSHAKE_ERROR","Handshake error when connecting to serviceNodeId %s ", MarkerFactory.getMarker("PP_APPLY_SSL_HANDSHAKE")),


    //****** Offline submit request **********//
    FS_MISSING_MANDATORY_FIELDS_ERROR("FS_MISSING_MANDATORY_FIELDS_ERROR", "%s field%s %s mandatory."),
    FS_APPLY_STATUS_NOT_FIND_ERROR("FS_APPLY_STATUS_NOT_FIND_ERROR", "Apply status not find with _id %s"),
    FS_OFFLINE_SUBMIT_NODE_NOT_FIND_ERROR("FS_OFFLINE_SUBMIT_NODE_NOT_FIND_ERROR", "Offline submit node config is not defined"),
    FS_OFFLINE_STATUS_UPDATE_ERROR("FS_OFFLINE_STATUS_UPDATE_ERROR", "Exception while updating offline status in atsApplyStatus"),

    //**** Validate ***//
    FS_VALIDATE_CONFIG_PARSING_ERROR("FS_VALIDATE_CONFIG_PARSING_ERROR", "Exception while parsing input config json to flow config object."),
    FS_VALIDATE_INIT_ERROR("FS_VALIDATE_INIT_ERROR", "Exception while validating init."),
    FS_VALIDATE_FLOW_IDENTIFIER_ERROR("FS_VALIDATE_FLOW_IDENTIFIER_ERROR", "Exception while validating flow identifier."),
    FS_VALIDATE_FLOW_ERROR("FS_VALIDATE_FLOW_ERROR", "Exception while validating flow."),
    FS_VALIDATE_FLOW_SEQUENCE_ERROR("FS_VALIDATE_FLOW_SEQUENCE_ERROR", "Exception while validating flow sequence."),
    FS_VALIDATE_STEPS_ERROR("FS_VALIDATE_STEPS_ERROR", "Exception while validating steps sequence."),
    FS_VALIDATE_STEP_ERROR("FS_VALIDATE_STEP_ERROR", "Exception while validating step sequence."),
    FS_VALIDATE_STEP_SUBMIT_ERROR("FS_VALIDATE_STEP_SUBMIT_ERROR", "Exception while validating step submit."),
    FS_VALIDATE_OFFLINE_SUBMIT_ERROR("FS_VALIDATE_OFFLINE_SUBMIT_ERROR", "Exception while validating offline submit."),
    FS_VALIDATE_NODE_CONFIG_ERROR("FS_VALIDATE_NODE_CONFIG_ERROR","Exception while validating node configs."),
    FS_VALIDATE_NODE_CONFIGS_ERROR("FS_VALIDATE_NODE_CONFIGS_ERROR","Exception while validating node config."),
    FS_VALIDATE_RULE_ERROR("FS_VALIDATE_RULE_ERROR","Exception while validating rule."),
    FS_VALIDATE_SWITCH_RULE_CONFIGS_ERROR("FS_VALIDATE_SWITCH_RULE_CONFIGS_ERROR","Exception while validating switch rule."),

    //**** Scheduler and PreScreening ***//
    FS_PRESCREENING_PROCESS_ERROR("FS_PRESCREENING_PROCESS_ERROR","Exception in PreScreening Process"),
    FS_PRESCREENING_BOTSERVICE_ERROR("FS_PRESCREENING_BOTSERVICE_ERROR","Exception in Bot Service PreScreening Process"),
    FS_SCHEDULER_GET_PSQ_DATA_ERROR("FS_SCHEDULER_GET_PSQ_DATA_ERROR", "Exception while getting preScreeningData from Scheduler"),

    //****** Crm Move Candidate To Job **********//
    FS_CRM_MOVECANDTOJOB_RECORD_CREATE_ERROR("FS_CRM_MOVECANDTOJOB_RECORD_CREATE_ERROR", "Exception while creating applyStatus record for moveCandidateToJob"),
    FS_CRM_MOVECANDTOJOB_NODE_NOT_FIND_ERROR("FS_CRM_MOVECANDTOJOB_NODE_NOT_FIND_ERROR", "Crm moveCandidateToJob node is not defined");

    private String statusCode;
    private String statusMsg;
    private Marker marker;


    StatusCodeEnum(String statusCode, String statusMsg) {
      this.statusCode = statusCode;
      this.statusMsg = statusMsg;
    }

    StatusCodeEnum(String statusCode, String statusMsg, Marker marker) {
        this.statusCode = statusCode;
        this.statusMsg = statusMsg;
        this.marker = marker;
    }

    public String getStatusCode() {
      return statusCode;
    }

    public void setStatusCode(String statusCode) {
      this.statusCode = statusCode;
    }

    public String getStatusMsg() {
      return statusMsg;
    }

    public Marker getMarker() {
        return marker;
    }

    public void setMarker(Marker marker) {
        this.marker = marker;
    }
}
