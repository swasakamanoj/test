package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldMapperWithDBUpdateFlag extends FieldMapper {

    private boolean isUpdateInDB;

    public boolean isUpdateInDB() {
        return isUpdateInDB;
    }

    public void setUpdateInDB(boolean updateInDB) {
        isUpdateInDB = updateInDB;
    }
}
