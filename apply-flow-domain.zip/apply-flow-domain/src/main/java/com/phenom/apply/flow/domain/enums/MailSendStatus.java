package com.phenom.apply.flow.domain.enums;

/**
 * @author Manoj Swasaka on 11/3/19
 * @project apply-flow-domain
 */
public enum MailSendStatus {

    SUCCESS("SUCCESS"),ALWAYS("ALWAYS");

    private String mailSendStatus;



    MailSendStatus(String mailSendStatus) {
        this.mailSendStatus = mailSendStatus;
    }


    public String mailSendStatus() {
        return mailSendStatus;
    }

}
