package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Map;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SwitchRule implements PhenomRule {

    private SwitchFieldData fieldData;
    private Map<String, RuleResultProcess> cases;


    public SwitchFieldData getFieldData() {
        return fieldData;
    }

    public void setFieldData(SwitchFieldData fieldData) {
        this.fieldData = fieldData;
    }

    public Map<String, RuleResultProcess> getCases() {
        return cases;
    }

    public void setCases(Map<String, RuleResultProcess> cases) {
        this.cases = cases;
    }

}
