package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum RuleOperatorEnum {

    equalsIgnoreCase("equalsIgnoreCase"),
    equals("equals"),
    notEquals("notEquals"),
    startWith("startWith"),
    contains("contains"),
    in("in");

    private String ruleOperator;
    /**
     * Constructor method
     *
     * @param ruleOperator
     */
    RuleOperatorEnum(String ruleOperator) {
        this.ruleOperator = ruleOperator;
    }

    /**
     * Method to get ruleOperator string from ENUM
     * @return String
     */
    public String ruleOperator() {
        return ruleOperator;
    }

}
