package com.phenom.apply.flow.domain.rule;

/**
 * @author Venu
 */
public interface PhenomRule {

}
