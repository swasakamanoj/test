package com.phenom.apply.flow.domain.config;

public class CrmMoveCandidateToJobIdentifier {
    private String nodeConfigId;

    public String getNodeConfigId() {
        return nodeConfigId;
    }

    public void setNodeConfigId(String nodeConfigId) {
        this.nodeConfigId = nodeConfigId;
    }

}
