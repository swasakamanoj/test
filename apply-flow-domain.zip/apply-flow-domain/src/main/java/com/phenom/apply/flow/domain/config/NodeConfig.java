package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.phenom.apply.flow.domain.enums.FunctionEnum;
import com.phenom.apply.flow.domain.enums.InternalApplyServiceEnum;
import com.phenom.apply.flow.domain.enums.NodeConfigEnum;
import com.phenom.apply.flow.domain.mail.Email;
import com.phenom.apply.flow.domain.rule.PhenomRule;
import com.phenom.apply.flow.domain.rule.PhenomRuleDeserialize;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class NodeConfig {

    private NodeConfigEnum type;
    private JsonNode value;
    private String serviceNodeConfigId;
    private String offlineConfigId;
    private FunctionEnum function;
    private InternalApplyServiceEnum internalApplyServiceId;
    private PhenomRule rule;
    private List<FieldMapperWithDBUpdateFlag> addToMetadataObject;
    private List<GatewayCustomRequestMapper> gatewayRequestMappers;
    private Email email;

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }

    public NodeConfig() {
    }

    public NodeConfig(NodeConfigEnum type, String serviceNodeConfigId) {
        this.type = type;
        this.serviceNodeConfigId = serviceNodeConfigId;
    }

    public NodeConfig(NodeConfigEnum type, String serviceNodeConfigId,
                      List<FieldMapperWithDBUpdateFlag> addToMetadataObject) {
        this.type = type;
        this.serviceNodeConfigId = serviceNodeConfigId;
        this.addToMetadataObject = addToMetadataObject;
    }

    public JsonNode getValue() {
        return value;
    }

    public void setValue(JsonNode value) {
        this.value = value;
    }

    public NodeConfigEnum getType() {
        return type;
    }

    public void setType(NodeConfigEnum type) {
        this.type = type;
    }

    public String getServiceNodeConfigId() {
        return serviceNodeConfigId;
    }

    public void setServiceNodeConfigId(String nextNodeConfigId) {
        this.serviceNodeConfigId = nextNodeConfigId;
    }

    public String getOfflineConfigId() {
        return offlineConfigId;
    }

    public void setOfflineConfigId(String offlineConfigId) {
        this.offlineConfigId = offlineConfigId;
    }

    @JsonDeserialize(using = PhenomRuleDeserialize.class)
    public PhenomRule getRule() {
        return rule;
    }

    public void setRule(PhenomRule rule) {
        this.rule = rule;
    }

    public List<FieldMapperWithDBUpdateFlag> getAddToMetadataObject() {
        return addToMetadataObject;
    }

    public void setAddToMetadataObject(List<FieldMapperWithDBUpdateFlag> addToMetadataObject) {
        this.addToMetadataObject = addToMetadataObject;
    }

    public void addAddToMetadataObject(FieldMapperWithDBUpdateFlag addToMetadataObject) {
        if (this.addToMetadataObject == null) {
            this.addToMetadataObject = new ArrayList<>();
        }
        this.addToMetadataObject.add(addToMetadataObject);
    }

    public InternalApplyServiceEnum getInternalApplyServiceId() {
        return internalApplyServiceId;
    }

    public void setInternalApplyServiceId(InternalApplyServiceEnum internalApplyServiceId) {
        this.internalApplyServiceId = internalApplyServiceId;
    }


    public FunctionEnum getFunction() {
        return function;
    }

    public void setFunction(FunctionEnum function) {
        this.function = function;
    }

    public List<GatewayCustomRequestMapper> getGatewayRequestMappers() {
        return gatewayRequestMappers;
    }

    public void setGatewayRequestMappers(List<GatewayCustomRequestMapper> gatewayRequestMappers) throws Throwable {
        if (gatewayRequestMappers != null && gatewayRequestMappers.size() > 1) {
            throw new Throwable("One custom request mapping will support with ATS_APPLY_DATA object.");
        }
        this.gatewayRequestMappers = gatewayRequestMappers;
    }


}
