package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum NodeConfigEnum {
    //GATEWAY_SERVICE, CUSTOM_SERVICE, RULE
    STATIC("STATIC"),
    GATEWAY_SERVICE("GATEWAY_SERVICE"),
    CUSTOM_SERVICE("CUSTOM_SERVICE"),
    INTERNAL_APPLY_SERVICE("INTERNAL_APPLY_SERVICE"),
    EMAIL_SERVICE("EMAIL_SERVICE"),
    RULE("RULE");

    private String nodeConfigType;

    /**
     * Constructor method
     *
     * @param nodeConfigType
     */
    NodeConfigEnum(String nodeConfigType) {
        this.nodeConfigType = nodeConfigType;
    }

    /**
     * Method to get nodeConfigType string from ENUM
     * @return String
     */
    public String nodeConfigType() {
        return nodeConfigType;
    }

}
