package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define collection names
 *
 * @author Venu
 */

public enum PreReqObjectEnum {

    JOB("JOB");

    private String preReqObject;

  /**
   * Constructor method
   *
   * @param preReqObject
   */
  PreReqObjectEnum(String preReqObject) {
      this.preReqObject = preReqObject;
    }

  /**
   * Method to get preReqObject string from ENUM
   * @return String
   */
  public String preReqObject() {
      return preReqObject;
    }

  }
