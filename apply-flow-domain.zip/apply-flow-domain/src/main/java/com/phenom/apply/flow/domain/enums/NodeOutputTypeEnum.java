package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define collection names
 *
 * @author Venu
 */

public enum NodeOutputTypeEnum {

    STATIC("STATIC"),
    NODE_CONFIG("NODE_CONFIG");

    private String outputType;

  /**
   * Constructor method
   *
   * @param outputType
   */
  NodeOutputTypeEnum(String outputType) {
      this.outputType = outputType;
    }

  /**
   * Method to get outputType string from ENUM
   * @return String
   */
  public String outputType() {
      return outputType;
    }

  }
