package com.phenom.apply.flow.domain.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.phenom.apply.flow.domain.rule.IfRuleConfig;
import com.phenom.apply.flow.domain.rule.PhenomRule;
import com.phenom.apply.flow.domain.rule.SwitchRule;

import java.io.IOException;

/**
 * @author Manoj Swasaka on 19/12/18
 */
public class DataUtil {

    public static ObjectMapper getObjectMapper() {
        return new ObjectMapper();
    }

    /**
     * @param jsonParser
     * @param ruleName
     * @return
     * @throws IOException
     */
    public static PhenomRule getRule(JsonParser jsonParser, String ruleName) throws IOException {
        JsonNode rule = jsonParser.getCodec().readTree(jsonParser);
        ObjectMapper objectMapper = getObjectMapper();
        if (rule != null) {
            if (rule.has(ruleName)) {
                return objectMapper.convertValue(rule, SwitchRule.class);
            } else {
                return objectMapper.convertValue(rule, IfRuleConfig.class);
            }
        }
        return null;
    }

    /**
     * @param key
     * @return
     */
    public static JsonNode convertToJsonNode(String key) {
        ObjectMapper objectMapper = DataUtil.getObjectMapper();
        return objectMapper.convertValue(key, JsonNode.class);
    }
}
