package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonSubTypes;

/**
 * @author Venu
 */
@JsonSubTypes({
        @JsonSubTypes.Type(value = IfRuleWithCondition.class) ,
        @JsonSubTypes.Type(value = IfRuleWithOutCondition.class) })
public interface IfRule {

}
