package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define collection names
 *
 * @author Venu
 */

public enum HTTPMethodEnum {

    POST("POST"),
    PUT("PUT"),
    GET("GET"),
    DELETE("DELETE"),
    HEAD("HEAD"),
    CONNECT("CONNECT"),
    OPTIONS("OPTIONS"),
    PATCH("PATCH");

    private String httpMethod;

  /**
   * Constructor method
   *
   * @param httpMethod
   */
  HTTPMethodEnum(String httpMethod) {
      this.httpMethod = httpMethod;
    }

  /**
   * Method to get collection name string from ENUM
   * @return String
   */
  public String httpMethod() {
      return httpMethod;
    }

  }
