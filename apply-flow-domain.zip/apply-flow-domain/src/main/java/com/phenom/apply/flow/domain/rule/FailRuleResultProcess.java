package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FailRuleResultProcess {


    private RuleResultProcess processResult;
    private IfRuleConfig rule;

    public FailRuleResultProcess() {
    }

    public FailRuleResultProcess(RuleResultProcess processResult) {
        this.processResult = processResult;
    }

    public FailRuleResultProcess(RuleResultProcess processResult, IfRuleConfig rule) {
        this.processResult = processResult;
        this.rule = rule;
    }

    public RuleResultProcess getProcessResult() {
        return processResult;
    }

    public void setProcessResult(RuleResultProcess processResult) {
        this.processResult = processResult;
    }

    public IfRuleConfig getRule() {
        return rule;
    }

    public void setRule(IfRuleConfig rule) {
        this.rule = rule;
    }
}
