package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.phenom.apply.flow.domain.enums.RuleConditionEnum;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IfRuleWithCondition implements IfRule {

    private RuleConditionEnum condition;
    private List<IfRule> rules;


    public RuleConditionEnum getCondition() {
        return condition;
    }

    public void setCondition(RuleConditionEnum condition) {
        this.condition = condition;
    }

    public List<IfRule> getRules() {
        return rules;
    }

    public void setRules(List<IfRule> rules) {
        this.rules = rules;
    }

}
