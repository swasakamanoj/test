package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define applyMaintenance flags
 *
 * @author Venu
 */

public enum ApplyMaintenanceEnum {
/*
    YES("yes"),
    No("no"),
    OFFLINE("offline");

    private String applyMaintenance;

  *//**
   * Constructor method
   *
   * @param applyMaintenance
   *//*
  ApplyMaintenanceEnum(String applyMaintenance) {
      this.applyMaintenance = applyMaintenance;
    }

  *//**
   * Method to get applyMaintenance flag string from ENUM
   * @return String
   *//*
  public String applyMaintenance() {
      return applyMaintenance;
    }*/

  }
