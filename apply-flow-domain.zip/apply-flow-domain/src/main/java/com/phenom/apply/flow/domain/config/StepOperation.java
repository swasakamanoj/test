package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class StepOperation {

    private String nodeConfigId;

    public StepOperation() {
    }

    public String getNodeConfigId() {
        return nodeConfigId;
    }

    public void setNodeConfigId(String nodeConfigId) {
        this.nodeConfigId = nodeConfigId;
    }
}
