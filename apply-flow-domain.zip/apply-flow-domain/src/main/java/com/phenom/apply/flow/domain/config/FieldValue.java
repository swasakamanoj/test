package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldValue {

    private String fieldName;
    private JsonNode value;


    public FieldValue() {
    }

    public FieldValue(String fieldName) {
        this.fieldName = fieldName;
    }

    public FieldValue(String fieldName, JsonNode value) {
        this.fieldName = fieldName;
        this.value = value;
    }

    /**
     *
     * @return
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     *
     * @param fieldName
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    /**
     *
     * @return
     */
    public JsonNode getValue() {
        return value;
    }

    /**
     *
     * @param value
     */
    public void setValue(JsonNode value) {
        this.value = value;
    }

}
