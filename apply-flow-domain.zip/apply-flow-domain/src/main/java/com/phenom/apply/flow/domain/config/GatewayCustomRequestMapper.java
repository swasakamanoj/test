package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.phenom.apply.flow.domain.enums.SourceObjectEnum;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GatewayCustomRequestMapper {

    private SourceObjectEnum fromObj;
    private String[] fields;

    public GatewayCustomRequestMapper() {
        this.fromObj = SourceObjectEnum.ATS_APPLY_DATA;
    }

    public SourceObjectEnum getFromObj() {
        return fromObj;
    }

    public String[] getFields() {
        return fields;
    }

    public void setFields(String[] fields) {
        this.fields = fields;
    }
}
