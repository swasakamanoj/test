package com.phenom.apply.flow.domain;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Map;

public class AtsApplyStatus extends ObjectNode {


    AtsApplyStatus(JsonNodeFactory nc) {
        super(nc);
    }

    AtsApplyStatus(JsonNodeFactory nc, Map<String, JsonNode> kids) {
        super(nc, kids);
    }

}
