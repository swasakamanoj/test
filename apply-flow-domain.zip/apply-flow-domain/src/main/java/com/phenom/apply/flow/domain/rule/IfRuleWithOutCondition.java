package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.phenom.apply.flow.domain.enums.RuleFieldTypeEnum;
import com.phenom.apply.flow.domain.enums.RuleOperatorEnum;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class IfRuleWithOutCondition implements IfRule {

    private String field;
    private RuleFieldTypeEnum type;
    private RuleOperatorEnum operator;
    private Object value;
    private List<String> childOf;

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public RuleFieldTypeEnum getType() {
        return type;
    }

    public void setType(RuleFieldTypeEnum type) {
        this.type = type;
    }

    public RuleOperatorEnum getOperator() {
        return operator;
    }

    public void setOperator(RuleOperatorEnum operator) {
        this.operator = operator;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public List<String> getChildOf() {
        return childOf;
    }

    public void setChildOf(List<String> childOf) {
        this.childOf = childOf;
    }
}
