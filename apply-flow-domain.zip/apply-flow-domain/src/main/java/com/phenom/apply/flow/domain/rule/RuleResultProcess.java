package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.phenom.apply.flow.domain.config.FieldValue;
import com.phenom.apply.flow.domain.enums.RuleOutputTypeEnum;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RuleResultProcess {

    private RuleOutputTypeEnum outputType;
    private JsonNode output;
    private List<FieldValue> addToMetadataObject;

    public RuleResultProcess(){

    }

    public RuleResultProcess(RuleOutputTypeEnum outputType, JsonNode output) {
        this.outputType = outputType;
        this.output = output;
    }

    public RuleResultProcess(RuleOutputTypeEnum outputType, JsonNode output, List<FieldValue> addToMetadataObject) {
        this.outputType = outputType;
        this.output = output;
        this.addToMetadataObject = addToMetadataObject;
    }

    public JsonNode getOutput() {
        return output;
    }

    public void setOutput(JsonNode output) {
        this.output = output;
    }

    public List<FieldValue> getAddToMetadataObject() {
        return addToMetadataObject;
    }

    public void setAddToMetadataObject(List<FieldValue> addToMetadataObject) {
        this.addToMetadataObject = addToMetadataObject;
    }

    public RuleOutputTypeEnum getOutputType() {
        return outputType;
    }

    public void setOutputType(RuleOutputTypeEnum outputType) {
        this.outputType = outputType;
    }

}
