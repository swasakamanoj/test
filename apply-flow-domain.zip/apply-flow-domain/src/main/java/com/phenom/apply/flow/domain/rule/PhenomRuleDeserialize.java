package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.phenom.apply.flow.domain.util.DataUtil;

import java.io.IOException;

/**
 * @author Venu
 */
public class PhenomRuleDeserialize extends JsonDeserializer {

    /**
     *
     * @param jsonParser {@code {@link JsonParser }}
     * @param ctxt {@code {@link DeserializationContext }}
     * @return List<IfRule>
     * @throws {@link IOException}
     * @throws {@link JsonProcessingException}
     */
    public PhenomRule deserialize(JsonParser jsonParser, DeserializationContext ctxt)
            throws IOException {
        return (PhenomRule) DataUtil.getRule(jsonParser,"cases");
    }




}
