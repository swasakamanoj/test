package com.phenom.apply.flow.domain;

import com.fasterxml.jackson.databind.JsonNode;

public class PreScreeningResponse {

    private String refNum;
    private String jobSeqNo;
    private String username;
    private String preScreeningStatus;
    private JsonNode psqData;
    private JsonNode candidateProfile;
    private boolean preScreeningAnswered;
    private String preScreeningForm;
    private JsonNode preScreeningQuestions;

    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public String getJobSeqNo() {
        return jobSeqNo;
    }

    public void setJobSeqNo(String jobSeqNo) {
        this.jobSeqNo = jobSeqNo;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPreScreeningStatus() {
        return preScreeningStatus;
    }

    public void setPreScreeningStatus(String preScreeningStatus) {
        this.preScreeningStatus = preScreeningStatus;
    }

    public JsonNode getPsqData() {
        return psqData;
    }

    public void setPsqData(JsonNode psqData) {
        this.psqData = psqData;
    }

    public JsonNode getCandidateProfile() {
        return candidateProfile;
    }

    public void setCandidateProfile(JsonNode candidateProfile) {
        this.candidateProfile = candidateProfile;
    }

    public boolean isPreScreeningAnswered() {
        return preScreeningAnswered;
    }

    public void setPreScreeningAnswered(boolean preScreeningAnswered) {
        this.preScreeningAnswered = preScreeningAnswered;
    }

    public String getPreScreeningForm() {
        return preScreeningForm;
    }

    public void setPreScreeningForm(String preScreeningForm) {
        this.preScreeningForm = preScreeningForm;
    }

    public JsonNode getPreScreeningQuestions() {
        return preScreeningQuestions;
    }

    public void setPreScreeningQuestions(JsonNode preScreeningQuestions) {
        this.preScreeningQuestions = preScreeningQuestions;
    }
}
