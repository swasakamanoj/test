package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Data/Model class for flow configs
 *
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class  FlowConfig {

    private String parentRefNum;
    private String refNum;
    private ClientSpecificConfig clientSpecificConfig;
    private Init init;
    private JsonNode uiSettings;
    private boolean siteLevelLogin;
    private boolean applyLevelLogin;
    private FlowCodeIdentifier flowCodeIdentifier;
    private Map<String, Flow> flows;
    private Map<String, Step> steps;
    private OfflineSubmitIdentifier offlineATSSubmitIdentifier;
    private CrmMoveCandidateToJobIdentifier crmMoveCandidateToJobIdentifier;
    private Map<String, NodeConfig> nodeConfigs;
    private ResponsePreparer responsePreparer;


    @JsonProperty(required = true)
    public String getParentRefNum() {
        return parentRefNum;
    }

    public void setParentRefNum(String parentRefNum) {
        this.parentRefNum = parentRefNum;
    }

    @JsonProperty(required = true)
    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public ClientSpecificConfig getClientSpecificConfig() {
        return clientSpecificConfig;
    }

    public void setClientSpecificConfig(ClientSpecificConfig clientSpecificConfig) {
        this.clientSpecificConfig = clientSpecificConfig;
    }

    @JsonProperty(required = true)
    public Init getInit() {
        return init;
    }

    public void setInit(Init init) {
        this.init = init;
    }

    public JsonNode getUiSettings() {
        return uiSettings;
    }

    public void setUiSettings(JsonNode uiSettings) {
        this.uiSettings = uiSettings;
    }

    public boolean isSiteLevelLogin() {
        return siteLevelLogin;
    }

    public void setSiteLevelLogin(boolean siteLevelLogin) {
        this.siteLevelLogin = siteLevelLogin;
    }

    public boolean isApplyLevelLogin() {
        return applyLevelLogin;
    }

    public void setApplyLevelLogin(boolean applyLevelLogin) {
        this.applyLevelLogin = applyLevelLogin;
    }

    @JsonProperty(required = true)
    public FlowCodeIdentifier getFlowCodeIdentifier() {
        return flowCodeIdentifier;
    }

    public void setFlowCodeIdentifier(FlowCodeIdentifier flowCodeIdentifier) {
        this.flowCodeIdentifier = flowCodeIdentifier;
    }

    public Map<String, Flow> getFlows() {
        if(this.flows == null){
            this.flows = Collections.emptyMap();
        }
        return Collections.unmodifiableMap(this.flows);
    }

    public void setFlows(Map<String, Flow> flows) {
        this.flows = flows;
    }

    @JsonProperty(required = true)
    public Map<String, Step> getSteps()
    {
        if(this.steps == null){
            this.steps = Collections.emptyMap();
        }
        return Collections.unmodifiableMap(this.steps);
    }

    public void addSteps(String  key, Step step)
    {
        if(this.steps == null){
            this.steps = new HashMap<>();
        }
        this.steps.put(key, step);
    }

    @JsonProperty(required = true)
    public Map<String, NodeConfig> getNodeConfigs() {
        if(this.nodeConfigs == null){
            this.nodeConfigs = Collections.emptyMap();
        }
        return Collections.unmodifiableMap(this.nodeConfigs);
    }

    public void addNodeConfigs(String  key, NodeConfig nodeConfig) {
        if(this.nodeConfigs == null){
            this.nodeConfigs = new LinkedHashMap<>();
        }
        this.nodeConfigs.put(key, nodeConfig);
    }

    public OfflineSubmitIdentifier getOfflineATSSubmitIdentifier() {
        return offlineATSSubmitIdentifier;
    }

    public void setOfflineATSSubmitIdentifier(OfflineSubmitIdentifier offlineATSSubmitIdentifier) {
        this.offlineATSSubmitIdentifier = offlineATSSubmitIdentifier;
    }

    public CrmMoveCandidateToJobIdentifier getCrmMoveCandidateToJobIdentifier() {
        return crmMoveCandidateToJobIdentifier;
    }

    public void setCrmMoveCandidateToJobIdentifier(CrmMoveCandidateToJobIdentifier crmMoveCandidateToJobIdentifier) {
        this.crmMoveCandidateToJobIdentifier = crmMoveCandidateToJobIdentifier;
    }


    public ResponsePreparer getResponsePreparer() {
        return responsePreparer;
    }

    public void setResponsePreparer(ResponsePreparer responsePreparer) {
        this.responsePreparer = responsePreparer;
    }
}
