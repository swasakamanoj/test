package com.phenom.apply.flow.domain.mail;

public interface MailRequestData {
}
