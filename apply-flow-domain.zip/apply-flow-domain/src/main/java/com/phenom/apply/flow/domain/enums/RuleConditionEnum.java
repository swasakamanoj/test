package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum RuleConditionEnum {
    NONE("NONE"),
    AND("AND"),
    OR("OR");

    private String ruleCondition;
    /**
     * Constructor method
     *
     * @param ruleCondition
     */
    RuleConditionEnum(String ruleCondition) {
        this.ruleCondition = ruleCondition;
    }

    /**
     * Method to get ruleCondition string from ENUM
     * @return String
     */
    public String ruleCondition() {
        return ruleCondition;
    }
}
