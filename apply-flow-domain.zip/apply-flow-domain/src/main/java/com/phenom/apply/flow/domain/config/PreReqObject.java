package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.phenom.apply.flow.domain.enums.PreReqObjectEnum;

import java.util.List;
import java.util.Map;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PreReqObject {

    private PreReqObjectEnum objectName;
    private List<String> fields;
    private Map<String, JsonNode> staticJobs;


    public PreReqObject() {
    }

    public PreReqObject(PreReqObjectEnum objectName, List<String> fields) {
        this.objectName = objectName;
        this.fields = fields;
    }

    public PreReqObject(PreReqObjectEnum objectName, List<String> fields, Map<String, JsonNode> staticJobs) {
        this.objectName = objectName;
        this.fields = fields;
        this.staticJobs = staticJobs;
    }

    public Map<String, JsonNode> getStaticJobs() {
        return staticJobs;
    }

    public void setStaticJobs(Map<String, JsonNode> staticJobs) {
        this.staticJobs = staticJobs;
    }

    public PreReqObjectEnum getObjectName() {
        return objectName;
    }

    public void setObjectName(PreReqObjectEnum objectName) {
        this.objectName = objectName;
    }

    public List<String> getFields() {
        return fields;
    }

    public void setFields(List<String> fields) {
        this.fields = fields;
    }
}
