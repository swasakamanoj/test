package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FlowCodeIdentifier {

    private String nodeConfigId;
    private List<FieldMapper> addToMetadataObject;
    private String value;

    public List<FieldMapper> getAddToMetadataObject() {
        return addToMetadataObject;
    }

    public void setAddToMetadataObject(List<FieldMapper> addToMetadataObject) {
        this.addToMetadataObject = addToMetadataObject;
    }

    public String getNodeConfigId() {
        return nodeConfigId;
    }

    public void setNodeConfigId(String nodeConfigId) {
        this.nodeConfigId = nodeConfigId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
