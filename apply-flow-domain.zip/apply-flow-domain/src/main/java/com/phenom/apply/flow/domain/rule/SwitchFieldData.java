package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SwitchFieldData {
    private String field;
    private List<String> childOf;

    public SwitchFieldData() {
    }

    public SwitchFieldData(String field) {
        this.field = field;
    }

    public SwitchFieldData(String field, List<String> childOf) {
        this.field = field;
        this.childOf = childOf;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public List<String> getChildOf() {
        return childOf;
    }

    public void setChildOf(List<String> childOf) {
        this.childOf = childOf;
    }

}
