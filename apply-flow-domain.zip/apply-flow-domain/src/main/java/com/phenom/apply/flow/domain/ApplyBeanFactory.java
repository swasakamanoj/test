package com.phenom.apply.flow.domain;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.phenom.apply.flow.domain.enums.StatusCodeEnum;
import com.phenom.apply.flow.domain.util.DataUtil;

import java.lang.reflect.Constructor;

/**
 * Class for create a apply bean objects
 *
 * @author Venu
 */

public class ApplyBeanFactory {

    static ApplyBeanFactory applyBeanFactory;

    private ApplyBeanFactory() {
    }

    /**
     * @return
     */
    public synchronized static ApplyBeanFactory getInstance() {
        if (applyBeanFactory == null) {
            applyBeanFactory = new ApplyBeanFactory();
        }
        return applyBeanFactory;
    }

    /**
     * Method to get apply beans
     *
     * @param applyBeanEnum {@code} {@link ApplyBeanEnum}
     * @param <T>           is is extending {@code ObjectNode}
     * @return T extends ObjectNode
     * @throws Throwable
     */
    public <T extends ObjectNode> T getApplyBean(ApplyBeanEnum applyBeanEnum) throws Throwable {
        switch (applyBeanEnum) {
            case METADATA:
                return getApplyBean(Metadata.class);
            case REQUEST:
                return getApplyBean(Request.class);
            case JOB:
                return getApplyBean(Job.class);
            case APPLY_STATUS:
                return getApplyBean(AtsApplyStatus.class);
            case APPLY_DATA:
                return getApplyBean(AtsApplyData.class);
        }
        return null;
    }

    /**
     * Method to create bean
     *
     * @param clazz {@code @link{Class<? extends ObjectNode>}}
     * @return T extends ObjectNode
     * @throws Throwable
     */
    private <T extends ObjectNode> T getApplyBean(Class<? extends ObjectNode> clazz) throws Throwable {
        try {
            ObjectMapper objectMapper = DataUtil.getObjectMapper();
            Constructor constructor = clazz.getDeclaredConstructor(JsonNodeFactory.class);
            return ( T ) constructor.newInstance(objectMapper.getNodeFactory());
        } catch (Throwable cause) {
            StatusCodeEnum statusCodeEnum = StatusCodeEnum.FS_BEAN_CREATION_ERROR;
            String statusMsg = String.format(statusCodeEnum.getStatusMsg(), clazz.getName());
            throw new Throwable(statusMsg, cause);
        }
    }

    public ApplyContext getApplyContext() {
        return new ApplyContext(JsonNodeFactory.instance);
    }

    public enum ApplyBeanEnum {METADATA, REQUEST, JOB, APPLY_STATUS, APPLY_DATA}
}
