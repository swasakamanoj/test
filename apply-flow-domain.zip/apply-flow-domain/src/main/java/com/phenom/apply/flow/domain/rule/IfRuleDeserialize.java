package com.phenom.apply.flow.domain.rule;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.phenom.apply.flow.domain.util.DataUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author Venu
 */
public class IfRuleDeserialize extends JsonDeserializer {

    /**
     *
     * @param jsonParser {@code {@link JsonParser }}
     * @param ctxt {@code {@link DeserializationContext }}
     * @return List<IfRule>
     * @throws {@link IOException}
     * @throws {@link JsonProcessingException}
     */
    public List<IfRule> deserialize(JsonParser jsonParser, DeserializationContext ctxt)
            throws IOException, JsonProcessingException {
        List<IfRule> ifRuleList = new ArrayList<>();
        JsonNode ruleNode = jsonParser.getCodec().readTree(jsonParser);
        ObjectMapper objectMapper = DataUtil.getObjectMapper();;
        if(ruleNode.isArray()) {
            Iterator<JsonNode> ruleIterator = ruleNode.elements();
            while(ruleIterator.hasNext()){
                JsonNode rule = ruleIterator.next();
                if (rule.has("condition")) {
                    ifRuleList.add(objectMapper.convertValue(rule, IfRuleWithCondition.class));
                } else {
                    ifRuleList.add(objectMapper.convertValue(rule, IfRuleWithOutCondition.class));
                }
            }
        }
        return ifRuleList;
    }


}
