package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.phenom.apply.flow.domain.rule.IfRuleConfig;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class NextNodeConfig {

    private String staticValue;
    private IfRuleConfig rule;

    public NextNodeConfig() {

    }

    public NextNodeConfig(String staticValue, IfRuleConfig rule) {
        this.staticValue = staticValue;
        this.rule = rule;
    }

    public String getStaticValue() {
        return staticValue;
    }

    public void setStaticValue(String staticValue) {
        this.staticValue = staticValue;
    }

    public IfRuleConfig getRule() {
        return rule;
    }

    public void setRule(IfRuleConfig rule) {
        this.rule = rule;
    }
}
