package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Flow {

    private String flowName;
    private Integer flowNum;
    private List<String> flowStepSequence;
    private List<SummaryPageInfo> summaryPageConf;

    public String getFlowName() {
        return flowName;
    }

    public void setFlowName(String flowName) {
        this.flowName = flowName;
    }

    @JsonProperty(required = true)
    public List<String> getFlowStepSequence() {
        if(this.flowStepSequence == null){
            this.flowStepSequence = Collections.emptyList();
        }
        return Collections.unmodifiableList(this.flowStepSequence);
    }

    public void setFlowStepSequence(List<String> flowStepSequence) {
        this.flowStepSequence = flowStepSequence;
    }

    public void addFlowStepSequence(String flowStepSequence) {
        if(this.flowStepSequence == null){
            this.flowStepSequence = new ArrayList<>();
        }
        this.flowStepSequence.add(flowStepSequence);
    }

	public List<SummaryPageInfo> getSummaryPageConf() {
		return summaryPageConf;
	}

	public void addSummaryPageConf(SummaryPageInfo summaryPageInfo) {
		if(this.summaryPageConf == null) {
			this.summaryPageConf = new ArrayList<>();
		}
		this.summaryPageConf.add(summaryPageInfo);
	}

	public Integer getFlowNum() {
		return flowNum;
	}

	public void setFlowNum(Integer flowNum) {
		this.flowNum = flowNum;
	}
    
}
