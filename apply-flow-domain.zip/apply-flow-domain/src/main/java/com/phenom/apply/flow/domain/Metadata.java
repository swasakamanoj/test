package com.phenom.apply.flow.domain;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.POJONode;
import com.phenom.apply.flow.domain.constants.FlowConstants;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Metadata extends ObjectNode {


    Metadata(JsonNodeFactory nc) {
        super(nc);
    }

    Metadata(JsonNodeFactory nc, Map<String, JsonNode> kids) {
        super(nc, kids);
    }

    public String getRefNum() {
        return this.get(FlowConstants.REFNUM).asText();
    }

    public String getParentRefNum() {
        if (this.get(FlowConstants.PARENT_REFNUM) == null) {
            return getRefNum();
        } else {
            return this.get(FlowConstants.PARENT_REFNUM).asText();
        }
    }


    public String getUsername() {
        if (this.get(FlowConstants.USERNAME) != null) {
            return this.get(FlowConstants.USERNAME).asText();
        } else {
            return "";
        }
    }

    public String getJobSeqNo() {
        if (this.get(FlowConstants.JOB_SEQ_NO) != null) {
            return this.get(FlowConstants.JOB_SEQ_NO).asText();
        } else {
            return "";
        }
    }

    public String getNextStep() {
        if (this.get(FlowConstants.NEXT_STEP) != null) {
            return this.get(FlowConstants.NEXT_STEP).asText();
        } else {
            return "";
        }
    }

    public void setNextStep(String nextStep) {
        if (nextStep != null) {
            this.put(FlowConstants.NEXT_STEP, nextStep);
        } else {
            this.put(FlowConstants.NEXT_STEP, "");
        }
    }

    public String getJobId() {
        if (this.get(FlowConstants.JOB_ID) != null) {
            return this.get(FlowConstants.JOB_ID).asText();
        } else {
            return "";
        }
    }

    public String getJobLocation() {
        if (this.get(FlowConstants.JOB_LOCATION) != null) {
            return this.get(FlowConstants.JOB_LOCATION).asText();
        } else {
            return "";
        }
    }

    public String getJobTitle() {
        if (this.get(FlowConstants.JOB_TITLE) != null) {
            return this.get(FlowConstants.JOB_TITLE).asText();
        } else {
            return "";
        }
    }

    public String getStepNum() {
        if (this.get(FlowConstants.STEP_NUM) != null) {
            return this.get(FlowConstants.STEP_NUM).asText();
        } else {
            return "";
        }
    }

    public String getForm() {
        if (this.get(FlowConstants.FORM_KEY) != null) {
            return this.get(FlowConstants.FORM_KEY).asText();
        } else {
            return "";
        }
    }

    public boolean isAlreadyApplied() {
        JsonNode isAlreadyApplied = this.get(FlowConstants.IS_ALREADY_APPLIED_KEY);
        if (isAlreadyApplied != null && isAlreadyApplied.isBoolean()) {
            return isAlreadyApplied.asBoolean();
        } else {
            return false;
        }
    }

    public boolean isFinalStep() {
        JsonNode isFinalStep = this.get(FlowConstants.IS_FINAL_STEP);
        if (isFinalStep != null && isFinalStep.isBoolean()) {
            return isFinalStep.asBoolean();
        } else {
            return false;
        }
    }

    public String getApplySubmitType() {
        if (this.get(FlowConstants.APPLY_LOGIN_TYPE) != null) {
            return this.get(FlowConstants.APPLY_LOGIN_TYPE).asText();
        } else {
            return FlowConstants.REFRESH;
        }
    }


    public String getFlowCode() {
        if (this.get(FlowConstants.FLOW_CODE) != null) {
            return this.get(FlowConstants.FLOW_CODE).asText();
        } else {
            return "";
        }
    }

    public void setFlowCode(String flowCode) {
        this.put(FlowConstants.FLOW_CODE, flowCode);
    }

    public List<String> getFlowSequence() {
        if (this.get(FlowConstants.FLOW_STEP_SEQ) != null && this.get(FlowConstants.FLOW_STEP_SEQ).isPojo()) {
            return ( List ) (( POJONode ) this.get(FlowConstants.FLOW_STEP_SEQ)).getPojo();
        } else {
            return Collections.emptyList();
        }
    }
}
