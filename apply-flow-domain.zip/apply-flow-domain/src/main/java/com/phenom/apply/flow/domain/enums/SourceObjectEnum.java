package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum SourceObjectEnum {
    JOB("job"),
    REQUEST("request"),
    ATS_APPLY_STATUS("atsApplyStatus"),
    ATS_APPLY_DATA("atsApplyData"),
    META_DATA("metadata"),
    CURRENT_RESPONSE("currentResponse"),
    STATIC("static");
    //    FLOW_CONFIG("FLOW_CONFIG"),

    private String sourceObject;

    /**
     * Constructor method
     *
     * @param sourceObject
     */
    SourceObjectEnum(String sourceObject) {
        this.sourceObject = sourceObject;
    }

    /**
     * Method to get sourceObject string from ENUM
     *
     * @return String
     */
    public String sourceObject() {
        return sourceObject;
    }

}
