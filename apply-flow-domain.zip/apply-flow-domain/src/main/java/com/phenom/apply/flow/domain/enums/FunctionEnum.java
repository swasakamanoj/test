package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum FunctionEnum {
    JSQS("JSQS"),
    ALREADY_APPLIED("ALREADY_APPLIED"),
    SUBMIT("SUBMIT");

    private String function;

    /**
     * Constructor method
     *
     * @param function
     */
    FunctionEnum(String function) {
        this.function = function;
    }

    /**
     * Method to get function string from ENUM
     * @return String
     */
    public String sourceObject() {
        return function;
    }

}
