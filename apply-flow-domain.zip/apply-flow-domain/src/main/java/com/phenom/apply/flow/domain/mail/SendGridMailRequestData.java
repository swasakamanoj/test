package com.phenom.apply.flow.domain.mail;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;

import java.util.List;

/**
 * Data Model object for prepare mail request
 *
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SendGridMailRequestData implements MailRequestData {

    private String refNum;
    private String parentRefNum;
    private JsonNode substitutionObj;
    private String templateName;
    private String fromMail;
    private String fromName;
    private JsonNode commonObj;
    private String subject;
    private List<String> attachments;

    /**
     * With , separated string
     * ex: ex@mailinator.com,ex1@mailinator.com
     */
    private String toMails;

    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public String getParentRefNum() {
        return parentRefNum;
    }

    public void setParentRefNum(String parentRefNum) {
        this.parentRefNum = parentRefNum;
    }

    public JsonNode getSubstitutionObj() {
        return substitutionObj;
    }

    public void setSubstitutionObj(JsonNode substitutionObj) {
        this.substitutionObj = substitutionObj;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getFromMail() {
        return fromMail;
    }

    public void setFromMail(String fromMail) {
        this.fromMail = fromMail;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public JsonNode getCommonObj() {
        return commonObj;
    }

    public void setCommonObj(JsonNode commonObj) {
        this.commonObj = commonObj;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<String> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<String> attachments) {
        this.attachments = attachments;
    }

    public String getToMails() {
        return toMails;
    }

    public void setToMails(String toMails) {
        this.toMails = toMails;
    }
}
