package com.phenom.apply.flow.domain.http;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.phenom.apply.flow.domain.enums.HTTPMethodEnum;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class HttpRequestData {

    private String url;
    private HTTPMethodEnum httpMethodEnum;
    private long timeOut;
    private JsonNode requestObj;

    public HttpRequestData(String url, HTTPMethodEnum httpMethodEnum, long timeOut) {
        this.url = url;
        this.httpMethodEnum = httpMethodEnum;
        this.timeOut = timeOut;
    }

    public HttpRequestData(String url, HTTPMethodEnum httpMethodEnum, long timeOut, JsonNode requestObj) {
        this.url = url;
        this.httpMethodEnum = httpMethodEnum;
        this.timeOut = timeOut;
        this.requestObj = requestObj;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public HTTPMethodEnum getHttpMethodEnum() {
        return httpMethodEnum;
    }

    public void setHttpMethodEnum(HTTPMethodEnum httpMethodEnum) {
        this.httpMethodEnum = httpMethodEnum;
    }

    public long getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(long timeOut) {
        this.timeOut = timeOut;
    }

    public JsonNode getRequestObj() {
        return requestObj;
    }

    public void setRequestObj(JsonNode requestObj) {
        this.requestObj = requestObj;
    }
}
