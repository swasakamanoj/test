package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class OfflineSubmitIdentifier {

    private String nodeConfigId;

    public String getNodeConfigId() {
        return nodeConfigId;
    }

    public void setNodeConfigId(String nodeConfigId) {
        this.nodeConfigId = nodeConfigId;
    }

}
