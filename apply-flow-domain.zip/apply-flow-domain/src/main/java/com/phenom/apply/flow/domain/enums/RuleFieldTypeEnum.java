package com.phenom.apply.flow.domain.enums;

/**
 * @author Venu
 */
public enum RuleFieldTypeEnum {

    STRING("STRING"),
    DATE("DATE"),
    BOOLEAN("BOOLEAN"),
    INT("INT");

    private String ruleFieldType;
    /**
     * Constructor method
     *
     * @param ruleFieldType
     */
    RuleFieldTypeEnum(String ruleFieldType) {
        this.ruleFieldType = ruleFieldType;
    }

    /**
     * Method to get ruleFieldType string from ENUM
     * @return String
     */
    public String ruleFieldType() {
        return ruleFieldType;
    }


}
