package com.phenom.apply.flow.domain.constants;

/**
 *
 * @author Venu
 *
 */
public class FlowConstants {

    public static final String APPLY_FLOW_SERVICE_NAME = "Apply Flow Service";
    //*****URL*********//
    public static final String DEFAULT_URL_TIMEOUT = "url.default.timeout";
    //****END URL *****//

    // *************** Start Mongo Credentials **********************

    // *************** Start Apply Mongo Credentials **********************
    public static final String APPLY_MONGO_AUTHENTICATION = "apply.mongo.authentication";
    public static final String APPLY_MONGO_HOST = "apply.mongo.host";
    public static final String APPLY_MONGO_USERNAME = "apply.mongo.username";
    public static final String APPLY_MONGO_PASSWORD = "apply.mongo.password";
    public static final String APPLY_MONGO_DATABASE = "apply.mongo.databasename";
    // *************** End Apply Mongo Credentials **********************


    // *************** Redis Credentials **********************
    public static final String REDIS_MAX_POOL_SIZE = "redis.maxTotal";
    public static final String REDIS_TEST_ON_BORROW = "redis.testOnBorrow";
    public static final String REDIS_MAX_WAIT_TIME = "redis.maxWaitMillis";
    public static final String REDIS_HOST = "redis.host";
    public static final String REDIS_PORT = "redis.port";
    public static final String REDIS_DB_NAME = "redis.dbname";

    // *************** Kafka Credentials **********************
    public static final String KAFKA_API="kafka_property_phenomtrack_api";
    public static final String KAFKA_POOLSIZE="kafka_threadpool_corePoolSize";
    public static final String KAFKA_MAXPOOLSIZE="kafka_threadpool_maxPoolSize";
    public static final String KAFKA_WORKQUEUESIZE="kafka_threadpool_workQueueSize";

    // ********** Search ******************
    public static final String SEARCH_SERVICE_JOB_DETAILS_URL = "search.service.job.url";
    public static final String SEARCH_SERVICE_JOB_DETAILS_URL_TIMEOUT = "search.service.url.timeout";

    // ********** APPLY GATEWAY ******************
    public static final String APPLY_GATEWAY_SERVICE_URL = "apply.gateway.service.url";
    public static final String APPLY_GATEWAY_SERVICE_TIMEOUT = "apply.gateway.url.timeout";
    public static final String APPLY_GATEWAY_SERVICE_TYPE_KEY = "serviceType";
    public static final String APPLY_GATEWAY_SERVICE_TYPE = "apply";

    // ********** EVENTS ******************
    public static final String APPLY_EVENT_SERVICE_URL = "apply.event.service.url";
    public static final String APPLY_EVENT_SERVICE_TIMEOUT = "event.service.timeout";

    // ********** BOTS ******************
    public static final String APPLY_BOTS_SERVICE_PSQRESPONSES_URL = "bots.service.psqresponses.url";
    public static final String APPLY_BOTS_SERVICE_TIMEOUT = "bots.service.timeout";

    //** String Constants **//
    public static final String USERNAME = "username";
    public static final String EMAIL = "email";
    public static final String TRANSACTION_ID = "transactionId";
    public static final String REFRESH = "refresh";
    public static final String BACK = "back";
    public static final String REFNUM = "refNum";
    public static final String PT_SESSION = "pt_session";
    public static final String TENANT = "tenant";
    public static final String SESSION_ID = "sessionId";
    public static final String TOKEN_ID = "tokenId";
    public static final String QUESTION_ID = "qid";
    public static final String ANSWER = "answer";
    public static final String SOURCE_KEY = "source";

    public static final String PARENT_REFNUM = "parentRefNum";
    public static final String APPLY_TYPE = "applyType";
    public static final String APPLY_LOGIN_TYPE = "loginType";
    public static final String APPLY_SUBMIT_TYPE = "applySubmitType";
    public static final String APPLY_SUBMIT_ONLINE_TYPE = "online";
    public static final String APPLY_SUBMIT_OFFLINE_TYPE = "offline";
    public static final String APPLY_SUBMIT_OFFLINE_SUBMIT_TYPE = "offline-submit";
    public static final String APPLY_SUBMIT_CHAT_BOT_TYPE = "chatBot";
    public static final String APPLY_SUBMIT_CRM_TYPE = "CRM";
    public static final String APPLY_CHANNEL = "applyChannel";
    public static final String APPLY_CHANNEL_APPLY = "apply";
    public static final String APPLY_CHANNEL_CHAT_BOT = "phenomBot";

    public static final String JOB_SEQ_NO = "jobSeqNo";
    public static final String JOB_TITLE = "jobTitle";
    public static final String JOB_SOURCE_TITLE = "title";
    public static final String SITE_TYPE = "siteType";
    public static final String COMMON = "common";
    public static final String EVENT_DATA = "eventData";
    public static final String EVENT_TYPE = "eventType";
    public static final String DATA_EVENT_NAME = "apply_service_data";
    public static final String THANK_YOU_EVENT_NAME = "apply_thankYou";

    public static final String LOCALE = "locale";
    public static final String STEP_NUM = "stepNum";
    public static final String STEP_FORM = "step";
    public static final String CATEGORY = "category";
    public static final String JOB_LOCATION = "jobLocation";
    public static final String JOB_DATA = "jobData";
    public static final String FLOW_CODE = "flowCode";
    public static final String FLOW_STEP_SEQ = "flowStepSeq";
    public static final String NEXT_STEP = "nextStep";
    public static final String JOB_ID = "jobId";
    public static final String IS_INITIAL_STEP = "isInitialStep";
    public static final String IS_FINAL_STEP = "isFinalStep";
    public static final String GET_ONLY_FORM = "getOnlyForm";
    public static final String GOTO_STEPNUM = "gotoStepNum";

    public static final String LAST_UPDATED = "lastUpdated";
    public static final String DATE_CREATED = "dateCreated";
    public static final String DATE_APPLIED= "dateApplied";
    public static final String ATS_APPLY_DATA_ID = "atsApplyDataId";
    public static final String ATS_APPLY_STATUS_ID = "atsApplyStatusId";

    public static final String PRE_SCREENING_CONFIG = "preScreeningConfig";
    public static final String PRE_SCREENING_TYPE = "preScreeningType";
    public static final String PRE_SCREENING_TYPE_APPLY = "apply";
    public static final String PRE_SCREENING_TYPE_CRM = "CRM";
    public static final String PRE_SCREENING_STATUS = "preScreeningStatus";
    public static final String PRE_SCREENING_QUESTIONS_DATA = "psqData";
    public static final String PRE_SCREENING_RESPONSE = "preScreeningResponse";

    public static final String FORM_KEY = "form";
    public static final String DATA_KEY = "data";

    public static final String JSQS_DATA_KEY = "jsqsData";
    public static final String IS_ALREADY_APPLIED_KEY = "isAlreadyApplied";

    public static final String STEP_THANK_YOU = "thankyou";
    public static final String STEP_JOB_EXPIRED = "jobExpired";
    public static final String STEP_ALREADY_APPLIED = "alreadyApplied";


    public static final String IS_EXCEPTION_PROCESS = "isExceptionProcess";
    public static final String STATUS_KEY = "status";
    public static final String STATUS_MESSAGE_KEY = "statusMessage";    
    public static final String STATUS_COMPLETED_KEY = "completed";
    public static final String STATUS_CODE_KEY = "statusCode";
    public static final String STATUS_SUCCESS = "success";
    public static final String STATUS_OFFLINE_SUCCESS = "offline-success";
    public static final String STATUS_FAILURE = "failure";
    public static final String STATUS_ALREADY_APPLIED = "alreadyApplied";
    public static final String STATUS_JOB_EXPIRED = "jobExpired";
    public static final String STATUS_UNQUALIFIED = "unqualified";

    public static final String NEXT_NODE_ID = "nextNodeId";
    public static final String SERVICE_CONFIG_ID = "serviceConfigId";
    public static final String APPLY_CONTEXT = "applyContext";
    public static final String REQUEST_CONTEXT = "requestContext";

    //SendGrid Email settings
    public static final String ENABLE_SEND_ERROR_MAIL = "enable.send.error.mail";
    public static final String MAIL_TO = "mail.to";
    public static final String MAIL_FROM = "mail.from";
    public static final String MAIL_SERVICE_API_URL = "mail.service.api.url";
    public static final String MAIL_APPLY_ERROR_MAIL_TEMPLATE = "mail.apply.error.failure.template";
    public static final String MAIL_DEFAULT_REFNUM = "PHENA0059";
    public static final String SUBSTITUTIONS_KEY = "substitutions";
    public static final String TEMPLATE_NAME_KEY = "templateName";
    public static final String SUBJECT_KEY = "subject";
    public static final String FROM_NAME_KEY = "fromName";
    public static final String FROM_MAIL_KEY = "fromEmail";
    public static final String TO_MAIL_KEY = "toEmail";

    public static final String ERROR_DASH_BOARD_URL_TIMEOUT = "alert.dashboard.timeout";
    public static final String ERROR_DASH_BOARD_URL = "alert.dashboard.url";

    public static final String DROPDOWNS = "dropdowns";
    public static final String FILTER = "filter";
    public static final String ERROR = "error";
    public static final String FILTER_ERROR = "Please add the filter in the request.";

}
