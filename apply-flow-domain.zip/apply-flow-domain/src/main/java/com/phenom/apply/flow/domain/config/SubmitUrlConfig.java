package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.phenom.apply.flow.domain.enums.SubmitModeEnum;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubmitUrlConfig {

    private SubmitModeEnum submitMode;
    private String nodeConfigId;

    public SubmitUrlConfig() {
    }

    public SubmitUrlConfig(SubmitModeEnum submitMode, String nodeConfigId) {
        this.submitMode = submitMode;
        this.nodeConfigId = nodeConfigId;
    }

    public SubmitModeEnum getSubmitMode() {
        return submitMode;
    }

    public void setSubmitMode(SubmitModeEnum submitMode) {
        this.submitMode = submitMode;
    }

    public String getNodeConfigId() {
        return nodeConfigId;
    }

    public void setNodeConfigId(String nodeConfigId) {
        this.nodeConfigId = nodeConfigId;
    }
}
