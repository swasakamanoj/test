package com.phenom.apply.flow.domain;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.Map;

public class AtsApplyData extends ObjectNode {


    AtsApplyData(JsonNodeFactory nc) {
        super(nc);
    }

    AtsApplyData(JsonNodeFactory nc, Map<String, JsonNode> kids) {
        super(nc, kids);
    }

}
