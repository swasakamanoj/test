package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define collection names
 *
 * @author Venu
 */

public enum RuleOutputTypeEnum {

    STATIC("STATIC");

    private String outputType;

  /**
   * Constructor method
   *
   * @param outputType
   */
  RuleOutputTypeEnum(String outputType) {
      this.outputType = outputType;
    }

  /**
   * Method to get outputType string from ENUM
   * @return String
   */
  public String outputType() {
      return outputType;
    }

  }
