package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Data/Model class for flow configs
 *
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientSpecificConfig {

    private String gatewayUrl;
    private Long gatewayTimeout;

    public String getGatewayUrl() {
        return gatewayUrl;
    }

    public void setGatewayUrl(String gatewayUrl) {
        this.gatewayUrl = gatewayUrl;
    }

    public Long getGatewayTimeout() {
        return gatewayTimeout;
    }

    public void setGatewayTimeout(Long gatewayTimeout) {
        this.gatewayTimeout = gatewayTimeout;
    }
}
