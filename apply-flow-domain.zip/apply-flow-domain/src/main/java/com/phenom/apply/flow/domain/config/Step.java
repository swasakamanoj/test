package com.phenom.apply.flow.domain.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Collections;
import java.util.List;

/**
 * @author Venu
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class Step {

    private String stepName;
    private List<FieldMapper> formQuery;
    private List<StepOperation> stepPreOperations;
    private List<StepOperation> stepPostOperations;
    private List<StepOperation> formInitOperations;
    private SubmitUrlConfig submitUrlConfig;

    public String getStepName() {
        return stepName;
    }

    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    public List<FieldMapper> getFormQuery() {
        if(this.formQuery != null){
            return this.formQuery;
        }
        return null;
    }

    public void setFormQuery(List<FieldMapper> formQuery) {
        this.formQuery = formQuery;
    }

    public List<StepOperation> getStepPreOperations() {
        if(this.stepPreOperations != null){
            return this.stepPreOperations;
        }
        return null;
    }

    public void setStepPreOperations(List<StepOperation> stepPreOperations) {
        this.stepPreOperations = stepPreOperations;
    }

    public List<StepOperation> getFormInitOperations() {
        if(this.formInitOperations != null){
            return this.formInitOperations;
        }
        return null;
    }

    public void setFormInitOperations(List<StepOperation> formInitOperations) {
        this.formInitOperations = formInitOperations;
    }


    public List<StepOperation> getStepPostOperations() {
        if(this.stepPostOperations != null){
            return this.stepPostOperations;
        }
        return null;
    }

    public void setStepPostOperations(List<StepOperation> stepPostOperations) {
        this.stepPostOperations = stepPostOperations;
    }

    public SubmitUrlConfig getSubmitUrlConfig() {
        return submitUrlConfig;
    }

    public void setSubmitUrlConfig(SubmitUrlConfig submitUrlConfig) {
        this.submitUrlConfig = submitUrlConfig;
    }
}
