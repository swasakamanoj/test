package com.phenom.apply.flow.domain.enums;

/**
 *
 * Enum to define collection names
 *
 * @author Venu
 */

public enum DBCollectionNameEnum {

    ATS_APPLY_STATUS("apply.mongo.collection.atsApplyStatus"),
    APPLY_JSQS("apply.mongo.collection.applyJSQs"),
    //ATS_APPLY_STATUS_NEXT_INDEX("atsApplyStatus.next_id"),
    ATS_APPLY_DATA("apply.mongo.collection.atsApplyData"),
    //ATS_APPLY_DATA_NEXT_INDEX("atsApplyData.next_id"),
    APPLY_FLOW_CONFIG("apply.mongo.collection.applyFlowConfig"),
    ATS_DROPDOWN("apply.mongo.collection.atsDropDown"),
    APPLY_PSQ_VALID_ANS("apply.mongo.collection.applyPsqValidAns"),
    ATS_SPECIFIC("apply.mongo.collection.atsSpecific");

    private String collectionName;

  /**
   * Constructor method
   *
   * @param collectionName
   */
  DBCollectionNameEnum(String collectionName) {
      this.collectionName = collectionName;
    }

  /**
   * Method to get collection name string from ENUM
   * @return String
   */
  public String collectionName() {
      return collectionName;
    }

  }
