package com.phenom.apply.flow.domain.config;

import java.util.List;

public class ResponsePreparer {
	
	private boolean sendProfile;
	private List<String> fields;
	
	public boolean isSendProfile() {
		return sendProfile;
	}
	public void setSendProfile(boolean sendProfile) {
		this.sendProfile = sendProfile;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}

}
