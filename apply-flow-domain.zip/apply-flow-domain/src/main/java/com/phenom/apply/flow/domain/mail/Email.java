package com.phenom.apply.flow.domain.mail;

import com.phenom.apply.flow.domain.config.FieldMapper;
import com.phenom.apply.flow.domain.enums.MailSendStatus;

import java.util.List;
import java.util.Map;

/**
 * @author Manoj Swasaka on 9/3/19
 * @project apply-flow-domain
 */
public class Email {

    private Map<String, String> templateName;

    private String formEmailId;

    private String senderName;

    private EmailSubject emailSubject;

    private List<FieldMapper> toRecipientList;

    private List<FieldMapper> ccRecipientList;

    private Map<String, FieldMapper> substitutionObject;

    private MailSendStatus mailSendStatusEnum;

    private List<FieldMapper> attachments;

    public List<FieldMapper> getAttachments() {
        return attachments;
    }

    public void setAttachments(List<FieldMapper> attachments) {
        this.attachments = attachments;
    }

    public MailSendStatus getMailSendStatusEnum() {
        return mailSendStatusEnum;
    }

    public void setMailSendStatusEnum(MailSendStatus mailSendStatusEnum) {
        this.mailSendStatusEnum = mailSendStatusEnum;
    }

    public Map<String, FieldMapper> getSubstitutionObject() {
        return substitutionObject;
    }

    public void setSubstitutionObject(Map<String, FieldMapper> substitutionObject) {
        this.substitutionObject = substitutionObject;
    }

    public Map<String, String> getTemplateName() {
        return templateName;
    }

    public void setTemplateName(Map<String, String> templateName) {
        this.templateName = templateName;
    }

    public String getFormEmailId() {
        return formEmailId;
    }

    public void setFormEmailId(String formEmailId) {
        this.formEmailId = formEmailId;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public EmailSubject getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(EmailSubject emailSubject) {
        this.emailSubject = emailSubject;
    }

    public List<FieldMapper> getToRecipientList() {
        return toRecipientList;
    }

    public void setToRecipientList(List<FieldMapper> toRecipientList) {
        this.toRecipientList = toRecipientList;
    }

    public List<FieldMapper> getCcRecipientList() {
        return ccRecipientList;
    }

    public void setCcRecipientList(List<FieldMapper> ccRecipientList) {
        this.ccRecipientList = ccRecipientList;
    }
}
