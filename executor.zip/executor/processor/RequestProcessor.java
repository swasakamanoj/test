package com.phenom.jobcast.executor.processor;

import com.phenom.jobcast.executor.util.Utility;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Message;
import org.apache.camel.util.CamelLogger;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;

/**
 * @author Manoj Swasaka on 2/7/19
 */
@Component
public class RequestProcessor {

    private static final CamelLogger LOGGER = new CamelLogger(RequestProcessor.class.getName(), LoggingLevel.INFO);
    private static final String DB_CONFIGURATION = "configuration";
    private static final String SERVICE_JOLT_CONFIG = "joltConfig";

    public void process(Exchange exchange) throws Exception {
        Message in = exchange.getIn();
        JSONObject request = new JSONObject(( LinkedHashMap ) in.getBody());
        if (in.getBody() != null) {
            net.minidev.json.JSONObject configuration =
                    Utility.getObjectMapper().readValue(exchange.getProperty(DB_CONFIGURATION).toString(),
                            net.minidev.json.JSONObject.class);
            String joltConfig = ( String ) configuration.get(SERVICE_JOLT_CONFIG);
            String finalRequest = Utility.prepareRequestWithJolt(request, joltConfig);
            if (finalRequest != null) {
                in.setBody(finalRequest);
                LOGGER.log(finalRequest, LoggingLevel.INFO);
            }
        }
    }

}

