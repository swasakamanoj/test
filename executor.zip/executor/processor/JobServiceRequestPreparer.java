package com.phenom.jobcast.executor.processor;

import com.phenom.jobcast.executor.config.PropertyConfigs;
import com.phenom.jobcast.executor.util.Utility;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Message;
import org.apache.camel.util.CamelLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;

/**
 * @author Manoj Swasaka on 27/6/19
 */
@Component
public class JobServiceRequestPreparer {

    private static final CamelLogger LOGGER = new CamelLogger(FailureResponsePreparer.class.getName(),
            LoggingLevel.INFO);
    private PropertyConfigs propertyConfigs;

    @Autowired
    public void setPropertyConfigs(PropertyConfigs propertyConfigs) {
        this.propertyConfigs = propertyConfigs;
    }

    public void process(Exchange exchange) throws Exception {
        Message in = exchange.getIn();
        if (in.getBody() != null) {
            org.json.JSONObject input = new org.json.JSONObject(( LinkedHashMap ) in.getBody());
            String joltConfig = propertyConfigs.getJobServiceJoltSpec();
            if (joltConfig != null && !joltConfig.isEmpty()) {
                String request = Utility.prepareRequestWithJolt(input, joltConfig);
                if (request != null) {
                    LOGGER.log("Request for JobService .... " + request, LoggingLevel.INFO);
                    in.setBody(request);
                }
            }
        }

    }
}
