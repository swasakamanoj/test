package com.phenom.jobcast.executor.processor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.phenom.jobcast.executor.transformations.MasterDataTransformation;
import com.phenom.jobcast.executor.util.Utility;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class BeisenFetchDataProcessor {
    private Logger log = LoggerFactory.getLogger(MasterDataTransformation.class);

    private static final String DATA_NODE = "data";
    private static final String JOBS_NODE = "jobs";

    public ArrayNode jobsNode;

    public void process(Exchange exchange) {
        Message message = exchange.getIn();
        String body = ( String ) message.getBody();
        ObjectMapper objectMapper = Utility.getObjectMapper();

        try {
            JsonNode jsonNode = objectMapper.readValue(body, JsonNode.class);

            if (jobsNode != null) {
                jobsNode.addAll(( ArrayNode ) (jsonNode.get(DATA_NODE).get(JOBS_NODE)));
            } else {
                jobsNode = ( ArrayNode ) (jsonNode.get(DATA_NODE).get(JOBS_NODE));
            }
            message.setBody(jobsNode);
            log.info("---------------Total fetched job:"+ jobsNode.size()+"-----------------");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
