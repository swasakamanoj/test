package com.phenom.jobcast.executor.processor;

import com.phenom.jobcast.executor.dto.FailureMessageDTO;
import com.phenom.jobcast.executor.util.Utility;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.util.CamelLogger;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 12/6/19
 */
@Component
public class FailureResponsePreparer implements Processor {
    private static final CamelLogger logger = new CamelLogger(FailureResponsePreparer.class.getName(),
            LoggingLevel.INFO);

    private ObjectFactory<FailureMessageDTO> failureMessageDTOObjectFactory;

    @Autowired
    public void setFailureMessageDTOObjectFactory(ObjectFactory<FailureMessageDTO> failureMessageDTOObjectFactory) {
        this.failureMessageDTOObjectFactory = failureMessageDTOObjectFactory;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        Message in = exchange.getIn();
        String body = in.getBody().toString();
        FailureMessageDTO failureMessageDTO = failureMessageDTOObjectFactory.getObject();
        failureMessageDTO.setStatus("Failure");
        if (in.getHeader("CamelHttpResponseCode") != null) {
            failureMessageDTO.setStatusCode(( Integer ) in.getHeader("CamelHttpResponseCode"));
        } else {
            failureMessageDTO.setStatusCode(500);
            in.setHeader("CamelHttpResponseCode", 500);
        }
        failureMessageDTO.setMessage(body);
        if (exchange.getException() != null) {
            failureMessageDTO.setError(exchange.getException().getMessage());
        }
        in.setBody(Utility.getObjectMapper().writeValueAsString(failureMessageDTO));
    }
}
