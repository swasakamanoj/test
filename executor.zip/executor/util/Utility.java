package com.phenom.jobcast.executor.util;

import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.JsonUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Manoj Swasaka on 18/6/19
 */
@Component
public class Utility {

    public static ObjectMapper getObjectMapper() {
        return new ObjectMapper();
    }

    public static String prepareRequestWithJolt(JSONObject request, String spec) throws JsonProcessingException {
        List<?> chainrConfig = JsonUtils.jsonToList(spec);
        Chainr chainr = Chainr.fromSpec(chainrConfig);
        Object input = JsonUtils.jsonToObject(request.toString());
        Object jsonOutput = chainr.transform(input);
        return Utility.getObjectMapper().writeValueAsString(jsonOutput);
    }

}
