package com.phenom.jobcast.executor.convertor;

import com.phenom.jobcast.executor.dto.JobBoardRequestDTO;
import com.phenom.jobcast.executor.util.Utility;
import org.apache.camel.Converter;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author Manoj Swasaka on 18/6/19
 * @project jobcast-executor-service
 */
@Component
public class ApplicationTypeConverters {

    @Converter
    public JobBoardRequestDTO byteArrayToJobBoardRequest(byte[] source) {
        try {
            return Utility.getObjectMapper().readValue(source, JobBoardRequestDTO.class);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
