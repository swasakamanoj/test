package com.phenom.jobcast.executor.enricher;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.phenom.jobcast.executor.util.Utility;
import net.minidev.json.JSONArray;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class BeisenDataEnricher {
    private static final String FROM = "from";
    private ObjectNode jsonNode;
    private ObjectMapper objectMapper = Utility.getObjectMapper();
    public ArrayNode requestsBody=objectMapper.createArrayNode();

    public void createRequestBody(Exchange exchange) {
        Message in = exchange.getIn();
        Integer start = ( Integer ) in.getHeader("start");
        String requestBody = ( String ) in.getBody();
        try {
            jsonNode = (ObjectNode) objectMapper.readValue(requestBody, JsonNode.class);
            jsonNode.put(FROM, start);
        } catch (IOException e) {
            e.printStackTrace();
        }
        requestsBody.add(jsonNode);
        in.setBody(requestsBody);
    }

}
