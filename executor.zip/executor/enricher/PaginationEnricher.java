package com.phenom.jobcast.executor.enricher;

import com.phenom.jobcast.executor.processor.BeisenFetchDataProcessor;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 17/7/19
 */
@Component
public class PaginationEnricher {

    @Autowired
    BeisenFetchDataProcessor fetchDataProcessor;

    @Autowired
    BeisenDataEnricher beisenDataEnricher;

    public void enrich(Exchange exchange) {
        Message in = exchange.getIn();
        Integer offset = in.getHeader("offset", Integer.class);
        Integer start = in.getHeader("start", Integer.class);
        start = start + offset;
        in.setHeader("start", start);
    }

    public void resetRequest(Exchange exchange) {
        fetchDataProcessor.jobsNode=null;
        beisenDataEnricher.requestsBody.removeAll();
        Message in = exchange.getIn();
        Integer start = in.getHeader("start", Integer.class);
        if (start==null){
            start=0;
            in.setHeader("start",start);
        }
    }
}
