package com.phenom.jobcast.executor.transformations;

import com.bazaarvoice.jolt.Transform;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import static com.mongodb.client.model.Filters.eq;

/**
 * Jolt tranformation class to map the values of input body to the master data values.
 */
public class MasterDataTransformation implements Transform {

    Logger log = LoggerFactory.getLogger(MasterDataTransformation.class);

    @Value("${mongodb.masterdatacollection}")
    String masterDataCollectionName;

    @Autowired
    MongoDatabase mongoDatabase;

    @Override
    public Object transform(Object o) {

        // Convert to LinkedHashMap
        Map<String, String> inputMap = new LinkedHashMap((Map) o);
        log.debug("The data to be transformed:\n{}", inputMap);

        // Get the routeId to retrieve the document with the master data for the given route
        String routeId = inputMap.get("routeId");

        if(StringUtils.isEmpty(routeId)){
            log.error("RouteId not found in the exchange's message body; transformation not possible.");
            return o;
        }

        MongoCollection<Document> masterDataCollection = mongoDatabase.getCollection(masterDataCollectionName);

        if(masterDataCollection == null){
            log.error("No collection with the name {} found!", masterDataCollectionName);
            return o;
        }

        Document masterDataDocument = masterDataCollection.find(eq("routeId", routeId)).first();

        if(masterDataDocument == null){
            log.error("No document with the routeId: {} found!", routeId);
            return o;
        }

        Set<String> keySet = masterDataDocument.keySet();

        for (Map.Entry inputDataEntry : inputMap.entrySet()) {
            // If the keySet of the master data document contains the entry key then update its value with master data
            // value
            if (keySet.contains(inputDataEntry.getKey()) && !inputDataEntry.getKey().equals("routeId")) {
                System.out.printf("Transforming: %s\n", inputDataEntry.getKey());
                String masterDataValue = (String) masterDataDocument.get(inputDataEntry.getKey(), Map.class)
                        .get(inputDataEntry.getValue());
                if (masterDataValue != null && !masterDataValue.trim().equals("")) {
                    inputMap.put(inputDataEntry.getKey().toString(), masterDataValue);
                }
            }
        }

        return inputMap;
    }

}
