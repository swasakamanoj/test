package com.phenom.jobcast.executor.config;


import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 2/7/19
 */
@Component
@ConfigurationPropertiesBinding
public class PropertyConfigs {

    @Value("${jobServiceJoltSpec}")
    private String jobServiceJoltSpec;

    public String getJobServiceJoltSpec() {
        return jobServiceJoltSpec;
    }

    public void setJobServiceJoltSpec(String jobServiceJoltSpec) {
        this.jobServiceJoltSpec = jobServiceJoltSpec;
    }
}
