package com.phenom.jobcast.executor.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoDatabase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Manoj Swasaka 
 */
@Component
@JsonIgnoreProperties
public class MongoDbConfigs {

    @Value("${mongodb.host}")
    private String mongoDbHost;

    @Value("${mongodb.port}")
    private int mongoDbPort;

    @Value("${databaseName}")
    private String mongoDbName;

    @Value("${mongodb.userName}")
    private String mongoDbUserName;

    @Value("${mongodb.watchword}")
    private String mongoDbWatchWord;

    @Bean
    MongoClient mongoClient() throws UnknownHostException {
        List<ServerAddress> serverAddressList = new ArrayList<>();
        String[] serverAddresses = mongoDbHost.split(",");
        for (String address : serverAddresses) {
            serverAddressList.add(new ServerAddress(address));
        }
        if (mongoDbUserName != null && !mongoDbUserName.isEmpty() && mongoDbWatchWord != null && !mongoDbWatchWord.isEmpty()) {
            return new MongoClient(serverAddressList, MongoCredential.createCredential(mongoDbUserName, mongoDbName,
                    mongoDbWatchWord.toCharArray()), new MongoClientOptions.Builder().build());
        } else {
            return new MongoClient(serverAddressList);
        }

    }

    @Bean
    public MongoDatabase getMongoDatabase() throws UnknownHostException {
        return mongoClient().getDatabase(mongoDbName);
    }

}
