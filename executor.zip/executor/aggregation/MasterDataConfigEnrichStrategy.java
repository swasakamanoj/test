package com.phenom.jobcast.executor.aggregation;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.bson.types.ObjectId;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author Manoj Swasaka on 10/7/19
 */
@Component
public class MasterDataConfigEnrichStrategy implements AggregationStrategy {

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

        Message oldExchangeIn = oldExchange.getIn();
        Message newExchangeIn = newExchange.getIn();
        Map<String, Map<String, String>> newBody =
                ( LinkedHashMap<String, Map<String, String>> ) newExchangeIn.getBody();
        Map<String, String> inputMap = new LinkedHashMap((Map) oldExchangeIn.getBody()); ;
        Set<String> keySet = newBody.keySet();
        for (Map.Entry inputDataEntry : inputMap.entrySet()) {
            if (keySet.contains(inputDataEntry.getKey()) && !inputDataEntry.getKey().equals("_id")) {
                String masterDataValue = newBody.get(inputDataEntry.getKey()).get(inputDataEntry.getValue());
                if (masterDataValue != null && !masterDataValue.trim().equals("")) {
                    inputMap.put(inputDataEntry.getKey().toString(), masterDataValue);
                }
            }
        }
        oldExchangeIn.setBody(inputMap);
        return oldExchange;
    }
}