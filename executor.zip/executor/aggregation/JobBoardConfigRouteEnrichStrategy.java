package com.phenom.jobcast.executor.aggregation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.jayway.jsonpath.DocumentContext;
import com.phenom.jobcast.executor.util.JSONPathUtility;
import com.phenom.jobcast.executor.util.Utility;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 12/6/19
 */
@Component
public class JobBoardConfigRouteEnrichStrategy implements AggregationStrategy {

    private JSONPathUtility jsonPathUtility;
    private ProducerTemplate producerTemplate;

    @Autowired
    public void setJsonPathUtility(JSONPathUtility jsonPathUtility) {
        this.jsonPathUtility = jsonPathUtility;
    }

    @Autowired
    public void setProducerTemplate(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }

    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        Message oldExchangeIn = oldExchange.getIn();
        Message newExchangeIn = newExchange.getIn();
        try {
            String oldInRequest = Utility.getObjectMapper().writeValueAsString(oldExchangeIn.getBody());
            DocumentContext documentContext = jsonPathUtility.parse(oldInRequest);
            String configRouteId = documentContext.read("$.configRouteIdentifier");
            String action = documentContext.read("$.action");

            String newInRequest = newExchangeIn.getBody().toString();
            DocumentContext documentContext1 = jsonPathUtility.parse(newInRequest);
            JSONArray configRoute = documentContext1.read("$.configRoutes[?(@ =='" + configRouteId + "')]");
            String finalConfigRouteId = ( String ) configRoute.get(0);
            if (finalConfigRouteId != null && !finalConfigRouteId.isEmpty()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("action", action);
                jsonObject.put("configRouteIdentifier", finalConfigRouteId);
                Exchange responseFromDb = retrieveDocumentFromAPIConfig(jsonObject);
                oldExchange.setProperty("configuration", responseFromDb.getIn().getBody());
                oldExchange.setProperty("configRouteId", "direct:" + configRouteId);
                oldExchange.setProperty("configRoute", configRouteId);
                oldExchange.setProperty("action", action);
            }

        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return oldExchange;
    }

    private Exchange retrieveDocumentFromAPIConfig(JSONObject requestBody) {
        return producerTemplate.request("direct:findOneByQueryJobBoardRouteConfig", new Processor() {
            @Override
            public void process(Exchange exchange) throws Exception {
                exchange.getIn().setBody(requestBody);

            }
        });
    }
}





