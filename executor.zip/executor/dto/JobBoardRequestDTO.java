package com.phenom.jobcast.executor.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 18/6/19
 * @project jobcast-executor-service
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Component
public class JobBoardRequestDTO {

    @Value("${refNum}")
    private String refNum;
    @Value("${configRouteIdentifier}")
    private String configRouteIdentifier;
    @Value("${action}")
    private String action;
    @Value("${jobSequenceId}")
    private String jobSequenceId;

    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public String getConfigRouteIdentifier() {
        return configRouteIdentifier;
    }

    public void setConfigRouteIdentifier(String configRouteIdentifier) {
        this.configRouteIdentifier = configRouteIdentifier;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getJobSequenceId() {
        return jobSequenceId;
    }

    public void setJobSequenceId(String jobSequenceId) {
        this.jobSequenceId = jobSequenceId;
    }
}
