package com.phenom.jobcast.executor.routes.beisen;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 2/7/19
 */
@Component
public class BeisenRouteBuilder extends RouteBuilder {

    @Override
    public void configure() throws Exception {


        from("direct:beisenRoute")
                .routeId("_Beisen_Route")
                .setBody(simple("{{beisen.default.requestbody}}")).convertBodyTo(String.class)
                .to("direct:postWithJsonBody")
                .to("{{beisen.data.fetch.uri}}")
                .convertBodyTo(String.class)
                .setHeader("count",jsonpath("$.totalHits"))
                .to("direct:beisenRouteSplitRequestBody");

        from("direct:beisenRouteSplitRequestBody")
                .routeId("_beisenRouteSplitRequestBody_")
                .choice()
                    .when(simple("${header.count} > 0"))
                        .setHeader("offset",constant("{{data.fetch.offset}}"))
                        .to("bean:paginationEnricher?method=resetRequest")
                        .loopDoWhile(simple("${header.start} <= ${header.count}"))
                            .to("seda:loadJobs?waitForTaskToComplete=Never")
                            .setBody(simple("{{beisen.default.requestbody}}"))
                            .to("bean:beisenDataEnricher?method=createRequestBody")
                            .to("bean:paginationEnricher?method=enrich")
                        .end()
                .split(simple("${body}")).parallelProcessing(true)
                .log("${body}")
                .to("direct:fetchJobsCountFromCMS")
                .end();


        from("direct:fetchJobsCountFromCMS")
                .routeId("_fetchJobsCountFromCMS")
                .setBody(simple("${body}")).convertBodyTo(String.class)
                .to("direct:postWithJsonBody")
                .to("{{beisen.data.fetch.uri}}")
                .convertBodyTo(String.class)
                .bean("beisenFetchDataProcessor");
        //TO DO need to implement jolt transformation and conversion

    }

}
