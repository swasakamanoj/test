package com.phenom.jobcast.executor.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 27/6/19
 *
 */
@Component
public class ApplicationHttpRouteBuilder extends RouteBuilder {
    @Override
    public void configure() throws Exception {

        from("direct:addJsonAcceptAndContentType").routeId("_Add_JSON_ContentType_Route").setHeader("Accept"
                , constant("application/json")).setHeader("Content-Type", constant("application/json"));


        from("direct:postWithJsonBody").routeId("_postHeader_Route").removeHeaders("CamelHttp*").to("direct:addJsonAcceptAndContentType").setHeader("CamelHttpMethod", constant("POST"));


        from("direct:getHeader").routeId("_getHeader_Route").setHeader("CamelHttpMethod", constant("GET"));


    }
}
