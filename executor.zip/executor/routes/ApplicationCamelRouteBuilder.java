package com.phenom.jobcast.executor.routes;

import com.phenom.jobcast.executor.aggregation.JobBoardConfigRouteEnrichStrategy;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.language.Simple;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestHostNameResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka 11/6/19
 */
@Component
public class ApplicationCamelRouteBuilder extends RouteBuilder {

    private JobBoardConfigRouteEnrichStrategy jobBoardConfigRouteEnrichStrategy;

    @Autowired
    public void setJobBoardConfigRouteEnrichStrategy(JobBoardConfigRouteEnrichStrategy jobBoardConfigRouteEnrichStrategy) {
        this.jobBoardConfigRouteEnrichStrategy = jobBoardConfigRouteEnrichStrategy;
    }

    @Override
    public void configure() {


        // Configured Rest let using camel routes
        restConfiguration().component("restlet").hostNameResolver(RestHostNameResolver.localHostName).port("9090");
        //Rest end points
        rest().path("/toJobBoard").consumes("application/json").post().to("direct:toJobBoard");

        rest().path("/ping").consumes("application/json").produces("application/json").get().to("direct:logResponse");

        //Exception handlers
        onException(org.apache.camel.component.jsonvalidator.JsonValidationException.class)
                .handled(true)
                .setBody(simple("Not a valid input"))
                .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(400))
                .to("direct:failureResponsePreparer");

        //Routes

        from("direct:toJobBoard")
                .routeId("_ToJobBoard_Route")
                .to("json-validator:jobBoardRequest.json")
                .unmarshal()
                .json(JsonLibrary.Jackson)
                .enrich("direct:getAllConfigRoutes", jobBoardConfigRouteEnrichStrategy)
                .toD("${exchangeProperty.configRouteId}");

        from("direct:jobService")
                .routeId("_JobService_Route")
                .to("bean:jobServiceRequestPreparer")
                .to("direct:postWithJsonBody")
                .to("{{jobServiceURI}}")
                .setBody().jsonpath("$."+"${exchangeProperty.action}"+"[0]");

        from("direct:failureResponsePreparer")
                .routeId("_Failure_Response_Route")
                .to("bean:failureResponsePreparer");

        from("direct:getAllConfigRoutes")
                .routeId("To_GetAllConfigRoutes")
                .setBody(simple("{{routs}}"))
                .convertBodyTo(String.class);

        from("direct:logResponse").
                routeId("_logResponse_Route")
                .log(LoggingLevel.DEBUG, "pingServiceLog", "In HealthCheck Route")
                .transform(simple("status:service is stable"));
    }
}