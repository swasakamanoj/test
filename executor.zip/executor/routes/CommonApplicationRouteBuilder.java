package com.phenom.jobcast.executor.routes;

import com.phenom.jobcast.executor.aggregation.MasterDataConfigEnrichStrategy;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 10/7/19
 */
@Component
public class CommonApplicationRouteBuilder extends RouteBuilder {

    private MasterDataConfigEnrichStrategy masterDataConfigEnrichStrategy;

    @Autowired
    public void setMasterDataConfigEnrichStrategy(MasterDataConfigEnrichStrategy masterDataConfigEnrichStrategy) {
        this.masterDataConfigEnrichStrategy = masterDataConfigEnrichStrategy;
    }

    @Override
    public void configure() throws Exception {

        from("direct:masterDataConfig").routeId("_masterDataConfig").enrich("direct:findOneByQueryJobBoardMasterDataConfig", masterDataConfigEnrichStrategy);
    }
}
