package com.phenom.jobcast.executor.routes.irishjobs;

import com.phenom.datatransform.utility.load.DataUtilityOperations;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 3/7/19
 *
 */
@Component
public class IrishJobsRouteBuilder  extends RouteBuilder {

    @Override
    public void configure() throws Exception {

        from("direct:irishJobsRoute")
                .routeId("_irishJobsRoute").
                to("direct:jobService")
                .to("direct:masterDataConfig")
                .bean("requestProcessor")
                .convertBodyTo(String.class)
                .log("${body}")
                .bean(DataUtilityOperations .class, "jsonToXmlParse(${body})");
    }
}
