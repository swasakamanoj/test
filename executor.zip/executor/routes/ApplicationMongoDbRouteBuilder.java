package com.phenom.jobcast.executor.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * @author Manoj Swasaka on 12/6/19
 *
 */
@Component
public class ApplicationMongoDbRouteBuilder extends RouteBuilder {

    @Override
    public void configure() {

        from("direct:findOneByQueryJobBoardRouteConfig").routeId("_findOneByQueryJobBoardRouteConfig").log("findOneByQueryJobBoardRouteConfig .... ${body}").toD("mongodb:mongoClient?database={{databaseName}}&collection={{jobboard_route_config_collection}}&operation=findOneByQuery").to("mock:resultFindOneByQuery").log("${body}");
        from("direct:findOneByQueryJobBoardMasterDataConfig").routeId("_findOneByQueryJobBoardMasterDataConfig").setBody(simple("{routeId:\"${exchangeProperty.configRoute}\"}")).log("findOneByQueryJobBoardRouteConfig .... ${body}").toD("mongodb:mongoClient?database={{databaseName}}&collection={{jobboard_master_data_config_collection}}&operation=findOneByQuery").to("mock:resultFindOneByQuery").log("${body}");
    }
}
